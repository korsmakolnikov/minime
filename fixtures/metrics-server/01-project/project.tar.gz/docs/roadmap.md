# Roadmap

1. metrics-server: receive metrics over HTTP and store them in Postgres.
2. A small dashboard reading from that store.
3. Alerting rules on top of the stored metrics.
