# Conventions

* Every tool is a self-contained project in its own folder, with its own
  Makefile, tests and CI.
* Services run locally with docker compose; no shared infrastructure.
* Metrics names follow the `domain.subject_unit` style (e.g.
  `http.request_duration_seconds`).
* Timestamps are always UTC.
