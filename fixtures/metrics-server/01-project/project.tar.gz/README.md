# observability-lab

A personal lab for small observability tools: collectors, storage
experiments and dashboards. Each tool lives in its own folder.

See `docs/` for the conventions every tool follows.
