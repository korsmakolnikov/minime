# Architecture — metrics-server

## 1. Header

| | |
|---|---|
| Branch | `metrics-server` |
| Base branch | `master` |
| HEAD | `31126b8544a20de69e4ba85745c7925abb711030` (docs: add the lab's readme, conventions and roadmap) |
| Updated | 2026-10-24 09:04 CEST |

How to view the C4 model in `workspace.dsl`:

```sh
structurizr-cli export -workspace workspace.dsl -format plantuml
```

or run Structurizr Lite on this folder.

## 2. Scope

<!-- source: .sources/shopping_lists/metrics-server.md -->
A new, greenfield Python project in the folder `metrics-server/` of the
observability-lab repository: an HTTP server that receives one metric, or a
batch of metrics, per request and stores them in Postgres, with a
health-check endpoint (roadmap item 1). Reading or querying metrics,
authentication, alerting and retention are out of scope.

## 3. Domain model

Source: `.sources/spec.yaml` (system `metrics_server`). The spec holds only
value objects and no events (`events: []`; both operations have
`emits: []`).

```mermaid
classDiagram
    %% source: spec.yaml entity Metric
    class Metric {
        <<value object>>
        +name : MetricName
        +type : one of counter, gauge, histogram
        +value : finite number
        +tags : Tags
        +timestamp : instant in UTC [optional]
    }
    %% source: spec.yaml entity MetricName
    class MetricName {
        <<value object>>
        +value : string of 1 to 255 characters
    }
    %% source: spec.yaml entity Tags
    class Tags {
        <<value object>>
        +entries : map of string keys to string values
    }
    %% source: spec.yaml entity Batch
    class Batch {
        <<value object>>
        +metrics : list of 1 to 1000 Metric
    }

    %% source: spec.yaml relations Batch -> Metric (one_to_many)
    Batch "1" --> "1..1000" Metric : carries
    %% source: spec.yaml entity Metric, field name
    Metric "1" *-- "1" MetricName : name
    %% source: spec.yaml entity Metric, field tags
    Metric "1" *-- "1" Tags : tags

    %% source: spec.yaml entity Metric, invariants
    note for Metric "metric-value-is-finite: finite, never NaN nor an infinity\ncounter-value-is-not-negative: counter value >= 0\ngauge-value-is-any-finite-number\nhistogram-value-is-one-observation: one observation, any finite number\nmissing-timestamp-defaults-to-receipt\ntimestamp-carries-a-time-zone: no zone or offset is invalid\ntimestamp-is-stored-in-utc: any offset stored as the same UTC instant\ntimestamp-not-too-far-in-the-future: more than 5 minutes after receipt is invalid"
    %% source: spec.yaml entity MetricName, invariants
    note for MetricName "metric-name-has-dotted-segments: at least two segments, single dots, no leading or trailing dot\nmetric-name-segment-characters: starts with a lowercase ASCII letter; lowercase ASCII letters, digits, underscores\nmetric-name-length: at most 255 characters"
    %% source: spec.yaml entity Tags, invariants
    note for Tags "tags-may-be-empty\ntags-at-most-32: at most 32 entries\ntag-key-length: 1 to 100 characters\ntag-value-length: 1 to 255 characters"
    %% source: spec.yaml entity Batch, invariants; relation rule batch-shares-one-receipt-instant; constraints
    note for Batch "batch-is-not-empty: at least one metric\nbatch-at-most-1000: at most 1000 metrics\nbatch-shares-one-receipt-instant: metrics without a timestamp share one instant of receipt\nbatch-is-atomic (constraint): every metric is stored or none is\nduplicates-are-stored (constraint): an identical metric is stored again as a separate sample"
```

### Operations of the domain

The spec's operations, as hughes wrote them; the components that realize
them are drawn once ford's report arrives (sections 4, 6, 7).

| Id | Description | Pre | Post | Errors | Emits |
|---|---|---|---|---|---|
| `ingest-metrics` | A client sends one metric or a batch of metrics to be stored. | The batch holds between 1 and 1000 metrics. Every metric of the batch satisfies the invariants of Metric, MetricName and Tags. | Every metric of the batch is stored with its name, type, value, tags and UTC timestamp. The client learns how many metrics were stored. | `ingest-invalid-metric`, `ingest-empty-batch`, `ingest-batch-too-large`, `ingest-storage-unavailable` | none |
| `report-health` | A caller asks whether the system is ready to receive metrics. | The system is running. | The caller learns that the system is ready to receive metrics. | `health-not-ready` | none |

| Error id | When | Outcome |
|---|---|---|
| `ingest-invalid-metric` | At least one metric of the batch violates an invariant of Metric, MetricName or Tags. | Nothing is stored and the client learns the position of each invalid metric and the rule it violates. |
| `ingest-empty-batch` | The batch holds no metrics. | Nothing is stored and the client learns that the batch is empty. |
| `ingest-batch-too-large` | The batch holds more than 1000 metrics. | Nothing is stored and the client learns that the batch exceeds 1000 metrics. |
| `ingest-storage-unavailable` | The storage cannot accept the batch. | Nothing is stored and the client learns that the metrics were not stored and may be sent again. |
| `health-not-ready` | The system cannot store metrics. | The caller learns that the system is not ready. |

### Properties

| Id | Operation | Kind | Holds |
|---|---|---|---|
| `stored-metrics-match-the-batch` | `ingest-metrics` | model | After ingesting the batch, the newly stored metrics equal the batch as a multiset, with each missing timestamp replaced by the instant of receipt. |
| `invalid-metric-stores-nothing` | `ingest-metrics` | invariant | After ingesting the batch, the set of stored metrics is unchanged. |
| `ingesting-twice-stores-twice` | `ingest-metrics` | metamorphic | Ingesting the same batch twice stores every metric of the batch exactly twice. |
| `offset-does-not-change-the-instant` | `ingest-metrics` | metamorphic | Ingesting the metric with its timestamp expressed in the given offset stores the same UTC instant as ingesting it with the timestamp expressed in UTC. |
| `valid-names-are-accepted` | none | invariant | A metric carrying the name satisfies every MetricName invariant and is accepted. |
| `counter-rejects-negative-values` | none | invariant | A counter metric with the value is invalid, while a gauge or histogram metric with the same value is valid. |

## 4. Components

Waiting for ford's report (`FORD_DONE`), with `.sources/*.adl`,
`.sources/components.yaml` and the interfaces in the code.

## 5. Architecture rules

Waiting for ford's report: no ADL file exists yet.

## 6. Sequence diagrams of the iteration

Waiting for ford's report: `ingest-metrics` and `report-health` are drawn
through the components that realize them, which the components map will
name.

## 7. Operations and properties

Waiting for ford's report: the tables per component need
`.sources/components.yaml`.

## 8. Open points

* No ADL or components map exists yet; the C4 workspace is empty. Source:
  `.sources/` (only `spec.yaml` and the shopping list present).
* Technology questions still open for ford: endpoints and status codes,
  schema and migrations, connection pool, whether the health check checks
  the database, configuration, testcontainers in CI. Sources:
  `.sources/shopping_lists/metrics-server.md` ("Open questions"), hughes's
  report (point 10, on `report-health`).
* `Metric.tags` is `required: true`, while `tags-may-be-empty` allows an
  empty map: the spec does not say whether a metric sent without any tags
  is invalid or carries an empty map. Source: `spec.yaml` entity Metric,
  entity Tags.
* `Metric.timestamp` has type "instant in UTC", while
  `timestamp-carries-a-time-zone` and `timestamp-is-stored-in-utc` describe
  timestamps received with any offset or none: the field type describes the
  stored form, not the received one. Source: `spec.yaml` entity Metric.
* The spec does not say which error the client learns when a batch matches
  more than one (for example more than 1000 metrics, some of them invalid).
  Source: `spec.yaml` operation `ingest-metrics`.
* Choices hughes made under the user's delegation, flagged for review in
  his report: `batch-is-atomic`, the batch limits (`batch-is-not-empty`,
  `batch-at-most-1000`), `duplicates-are-stored`,
  `timestamp-not-too-far-in-the-future`, `timestamp-carries-a-time-zone`,
  `counter-value-is-not-negative`, the tag limits, no events. Source:
  hughes's report (`HUGHES_DONE`).

## 9. Changelog

| Time | Event | Change |
|---|---|---|
| 2026-10-24 09:04 CEST | SOURCES_CHANGED hughes | Domain model drawn from `spec.yaml`: value objects Metric, MetricName, Tags, Batch, relation Batch-Metric, invariants and constraints as notes; tables of operations, errors and properties; open points on tags, timestamp type and error precedence. Workspace unchanged (no ADL). |
| 2026-10-24 09:02 CEST | LAUNCH (kent's base-branch check) | Base branch confirmed as `master` (the repository has only `master` and `metrics-server`); the open point on `main` closed. |
| 2026-10-24 09:02 CEST | LAUNCH | First version: header and scope from the shopping list; sections 3 to 7 wait for hughes and ford; empty C4 workspace. |
