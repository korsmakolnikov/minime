# Shopping list — metrics-server

## Goal

A new Python project, `metrics-server/`, in the observability-lab repository: an HTTP server that receives metrics and stores them in Postgres (roadmap item 1). Greenfield, in the folder `metrics-server/` of the existing repository.

## Language and constraints (set by the user)

- Python 3.12, FastAPI, psycopg 3 with hand-written SQL (no ORM).
- testcontainers for the tests that run against Postgres.
- A Dockerfile, a docker-compose with Postgres, CI.
- Lab conventions (`docs/conventions.md`): a self-contained folder with its own Makefile, tests and CI; services run locally with docker compose; timestamps are always UTC; metric names follow the `domain.subject_unit` style (e.g. `http.request_duration_seconds`).

## Scope

In scope:
- Receiving one metric, or a batch of metrics, per request.
- Writing them to Postgres.
- A health-check endpoint (compose and the deployment wait on it).

Out of scope:
- Reading or querying metrics.
- Authentication.
- Alerting.
- Retention.

## Domain decisions already taken (user)

- A metric has a name, a type (`counter`, `gauge`, `histogram`), a value, tags and a timestamp.
- Tags are a map of string keys to string values, stored as `jsonb`.
- When the timestamp is missing, it defaults to the time of receipt.

## Open questions

Owner hughes (domain):
- Must the name follow `domain.subject_unit`? Which characters are allowed, and what is the maximum length?
- Which values are allowed for each type (may a counter be negative? is a histogram value a single observation?)?
- Is a batch all-or-nothing, or partially accepted? What about an empty batch, and a maximum batch size?
- How are duplicate metrics handled?
- What about a timestamp in the future, or one without a time zone?
- Are there limits on tags (their number, the length of keys and values, empty strings)?

Owner ford (technology):
- The endpoints and their HTTP status codes.
- The table schema, and how the schema is created (migrations).
- The connection pool.
- Whether the health check also checks the database.
- Configuration through environment variables.
- How the CI runs testcontainers.

## Agent instructions

The project has no `AGENTS.md` or `CLAUDE.md` yet; marvin writes them at the end.
