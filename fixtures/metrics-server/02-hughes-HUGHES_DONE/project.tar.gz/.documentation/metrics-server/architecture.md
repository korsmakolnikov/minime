# Architecture — metrics-server

## 1. Header

| | |
|---|---|
| Branch | `metrics-server` |
| Base branch | `master` |
| HEAD | `31126b8544a20de69e4ba85745c7925abb711030` (docs: add the lab's readme, conventions and roadmap) |
| Updated | 2026-10-24 09:02 CEST |

How to view the C4 model in `workspace.dsl`:

```sh
structurizr-cli export -workspace workspace.dsl -format plantuml
```

or run Structurizr Lite on this folder.

## 2. Scope

<!-- source: .sources/shopping_lists/metrics-server.md -->
A new, greenfield Python project in the folder `metrics-server/` of the
observability-lab repository: an HTTP server that receives one metric, or a
batch of metrics, per request and stores them in Postgres, with a
health-check endpoint (roadmap item 1). Reading or querying metrics,
authentication, alerting and retention are out of scope.

## 3. Domain model

Waiting for hughes's `.sources/spec.yaml` (`HUGHES_DONE`). No entity, value
object, event, relation or invariant is drawn until the spec exists.

## 4. Components

Waiting for ford's report (`FORD_DONE`), with `.sources/*.adl`,
`.sources/components.yaml` and the interfaces in the code.

## 5. Architecture rules

Waiting for ford's report: no ADL file exists yet.

## 6. Sequence diagrams of the iteration

Waiting for ford's report: the sequences need the spec's operations and the
components that realize them.

## 7. Operations and properties

Waiting for ford's report: the tables need `.sources/components.yaml`.

## 8. Open points

* No spec, ADL or components map exists yet; the documentation holds only
  the scope. Sources: `.sources/` (only
  `shopping_lists/metrics-server.md` present).
* The shopping list lists open domain questions for hughes (name format,
  values per type, batch semantics, duplicates, timestamps, tag limits) and
  technology questions for ford (endpoints and status codes, schema and
  migrations, connection pool, health check of the database, configuration,
  testcontainers in CI). Source: `.sources/shopping_lists/metrics-server.md`,
  "Open questions".

## 9. Changelog

| Time | Event | Change |
|---|---|---|
| 2026-10-24 09:02 CEST | LAUNCH (kent's base-branch check) | Base branch confirmed as `master` (the repository has only `master` and `metrics-server`); the open point on `main` closed. |
| 2026-10-24 09:02 CEST | LAUNCH | First version: header and scope from the shopping list; sections 3 to 7 wait for hughes and ford; empty C4 workspace. |
