# Architecture — metrics-server

## 1. Header

| | |
|---|---|
| Branch | `metrics-server` |
| Base branch | `master` |
| HEAD | `75762698e94468861912a36c3223c2fad9f744bb` (test(metrics-server metrics): reject a metric name with a trailing dot) |
| Updated | 2026-10-24 15:33 CEST |

How to view the C4 model in `workspace.dsl`:

```sh
structurizr-cli export -workspace workspace.dsl -format plantuml
```

or run Structurizr Lite on this folder.

Paths below are relative to the repository root; `src/` stands for
`metrics-server/src/metrics_server/`.

## 2. Scope

<!-- source: .sources/shopping_lists/metrics-server.md -->
A new, greenfield Python project in the folder `metrics-server/` of the
observability-lab repository: an HTTP server that receives one metric, or a
batch of metrics, per request and stores them in Postgres, with a
health-check endpoint (roadmap item 1). Reading or querying metrics,
authentication, alerting and retention are out of scope.

## 3. Domain model

Source: `.sources/spec.yaml` (system `metrics_server`). The spec holds only
value objects and no events (`events: []`; both operations have
`emits: []`).

```mermaid
classDiagram
    %% source: spec.yaml entity Metric
    class Metric {
        <<value object>>
        +name : MetricName
        +type : one of counter, gauge, histogram
        +value : finite number
        +tags : Tags [optional]
        +timestamp : instant with a time zone or UTC offset when received, in UTC when stored [optional]
    }
    %% source: spec.yaml entity MetricName
    class MetricName {
        <<value object>>
        +value : string of 1 to 255 characters
    }
    %% source: spec.yaml entity Tags
    class Tags {
        <<value object>>
        +entries : map of string keys to string values
    }
    %% source: spec.yaml entity Batch
    class Batch {
        <<value object>>
        +metrics : list of 1 to 1000 Metric
    }

    %% source: spec.yaml relations Batch -> Metric (one_to_many)
    Batch "1" --> "1..1000" Metric : carries
    %% source: spec.yaml entity Metric, field name
    Metric "1" *-- "1" MetricName : name
    %% source: spec.yaml entity Metric, field tags (required false)
    Metric "1" *-- "0..1" Tags : tags

    %% source: spec.yaml entity Metric, invariants
    note for Metric "metric-value-is-finite: finite, never NaN nor an infinity\ncounter-value-is-not-negative: counter value >= 0\ngauge-value-is-any-finite-number\nhistogram-value-is-one-observation: one observation, any finite number\nmissing-timestamp-defaults-to-receipt\ntimestamp-carries-a-time-zone: no zone or offset is invalid\ntimestamp-is-stored-in-utc: any offset stored as the same UTC instant\ntimestamp-not-too-far-in-the-future: more than 5 minutes after receipt is invalid"
    %% source: spec.yaml entity MetricName, invariants
    note for MetricName "metric-name-has-dotted-segments: at least two segments, single dots, no leading or trailing dot\nmetric-name-segment-characters: starts with a lowercase ASCII letter; lowercase ASCII letters, digits, underscores\nmetric-name-length: at most 255 characters"
    %% source: spec.yaml entity Tags, invariants
    note for Tags "tags-may-be-empty\nmissing-tags-default-to-empty: no tags received means an empty map stored\ntags-at-most-32: at most 32 entries\ntag-key-length: 1 to 100 characters\ntag-value-length: 1 to 255 characters"
    %% source: spec.yaml entity Batch, invariants; relation rule batch-shares-one-receipt-instant; constraints
    note for Batch "batch-is-not-empty: at least one metric\nbatch-at-most-1000: at most 1000 metrics\nbatch-shares-one-receipt-instant: metrics without a timestamp share one instant of receipt\nbatch-is-atomic (constraint): every metric is stored or none is\nduplicates-are-stored (constraint): an identical metric is stored again\nbatch-size-error-takes-precedence (constraint): a size error hides invalid metrics\nstorage-error-only-for-a-valid-batch (constraint)"
```

### Operations of the domain

| Id | Description | Pre | Post | Errors | Emits |
|---|---|---|---|---|---|
| `ingest-metrics` | A client sends one metric or a batch of metrics to be stored. | The batch holds between 1 and 1000 metrics. Every metric of the batch satisfies the invariants of Metric, MetricName and Tags. | Every metric of the batch is stored with its name, type, value, tags and UTC timestamp. The client learns how many metrics were stored. | `ingest-invalid-metric`, `ingest-empty-batch`, `ingest-batch-too-large`, `ingest-storage-unavailable` | none |
| `report-health` | A caller asks whether the system is ready to receive metrics. | The system is running. | The caller learns that the system is ready to receive metrics. | `health-not-ready` | none |

| Error id | When | Outcome |
|---|---|---|
| `ingest-invalid-metric` | At least one metric of the batch violates an invariant of Metric, MetricName or Tags. | Nothing is stored and the client learns the position of each invalid metric and the rule it violates. |
| `ingest-empty-batch` | The batch holds no metrics. | Nothing is stored and the client learns that the batch is empty. |
| `ingest-batch-too-large` | The batch holds more than 1000 metrics. | Nothing is stored and the client learns that the batch exceeds 1000 metrics. |
| `ingest-storage-unavailable` | The storage cannot accept the batch. | Nothing is stored and the client learns that the metrics were not stored and may be sent again. |
| `health-not-ready` | The system cannot store metrics. | The caller learns that the system is not ready. |

## 4. Components

Sources: `.sources/system.adl`, `.sources/components.yaml` and the
interfaces in `src/`. One SYSTEM `metrics_server` with three COMPONENTs and
five LIBRARYs; no DOMAIN, SUBDOMAIN or SERVICE.

### metrics (`metrics_server.metrics`, boundary concrete)

Responsibility: the metric, its name, its tags and the batch a request
carries, and the rules that decide whether a batch may be stored; pure, no
I/O (`src/metrics/__init__.py:1`).

```mermaid
classDiagram
    %% source: metrics-server/src/metrics_server/metrics/__init__.py:119
    class metrics_module["metrics_server.metrics"] {
        <<module>>
        +parse_batch(items: Sequence[object], received_at: datetime) tuple[Metric, ...]
    }
    %% source: metrics-server/src/metrics_server/metrics/__init__.py:36
    class MetricType {
        <<enumeration>>
        COUNTER = counter
        GAUGE = gauge
        HISTOGRAM = histogram
    }
    %% source: metrics-server/src/metrics_server/metrics/__init__.py:45
    class Metric {
        <<frozen dataclass>>
        +name : str
        +type : MetricType
        +value : float
        +tags : Mapping[str, str]
        +timestamp : datetime
    }
    %% source: metrics-server/src/metrics_server/metrics/__init__.py:69
    class Violation {
        <<frozen dataclass>>
        +index : int
        +field : str | None
        +rule : str
    }
    %% source: metrics-server/src/metrics_server/metrics/__init__.py:93
    class InvalidBatch {
        <<exception>>
    }
    %% source: metrics-server/src/metrics_server/metrics/__init__.py:97
    class EmptyBatch {
        <<exception>>
    }
    %% source: metrics-server/src/metrics_server/metrics/__init__.py:101
    class BatchTooLarge {
        <<exception>>
    }
    %% source: metrics-server/src/metrics_server/metrics/__init__.py:105
    class InvalidMetrics {
        <<exception>>
        +violations : tuple[Violation, ...]
    }

    Metric --> MetricType
    InvalidBatch <|-- EmptyBatch
    InvalidBatch <|-- BatchTooLarge
    InvalidBatch <|-- InvalidMetrics
    InvalidMetrics --> "1..*" Violation
    %% source: metrics-server/src/metrics_server/metrics/__init__.py:133-143
    metrics_module ..> Metric : returns
    metrics_module ..> EmptyBatch : raises
    metrics_module ..> BatchTooLarge : raises
    metrics_module ..> InvalidMetrics : raises, only when the size is valid

    %% source: .sources/components.yaml metrics_server.metrics
    note for metrics_module "realizes: metric-value-is-finite, counter-value-is-not-negative, gauge-value-is-any-finite-number, histogram-value-is-one-observation, missing-timestamp-defaults-to-receipt, timestamp-carries-a-time-zone, timestamp-is-stored-in-utc, timestamp-not-too-far-in-the-future, metric-name-has-dotted-segments, metric-name-segment-characters, metric-name-length, tags-may-be-empty, tags-at-most-32, tag-key-length, tag-value-length, batch-is-not-empty, batch-at-most-1000, batch-shares-one-receipt-instant, valid-names-are-accepted, counter-rejects-negative-values, offset-does-not-change-the-instant, missing-tags-default-to-empty, batch-size-error-takes-precedence"
```

`parse_batch` takes `tags` as optional, an empty map when absent
(`src/metrics/__init__.py:125-128`). `Violation.rule` holds a spec
invariant id or one of four shape codes that are not in the spec:
`not-an-object`, `field-missing`, `field-unknown`, `field-invalid`
(`src/metrics/__init__.py:77-85`). By the user's decision, forwarded by
kent, these codes, the rejection of unknown fields and the `400
malformed-body` response are a detail of the HTTP contract (the shape of
the request), not domain rules.

### storage (`metrics_server.storage.MetricStore`, boundary interface)

Responsibility: writes validated metrics to Postgres; the only component
that talks to the database (`src/storage/__init__.py:1`).

```mermaid
classDiagram
    %% source: metrics-server/src/metrics_server/storage/__init__.py:33
    class MetricStore {
        <<interface>>
        +open() None
        +close() None
        +store(metrics: Sequence[Metric]) int
        +is_ready() bool
    }
    %% source: metrics-server/src/metrics_server/storage/__init__.py:64
    class PostgresMetricStore {
        +__init__(database_url: str)
        +open() None
        +close() None
        +store(metrics: Sequence[Metric]) int
        +is_ready() bool
    }
    %% source: metrics-server/src/metrics_server/storage/__init__.py:26
    class StorageUnavailable {
        <<exception>>
    }
    %% source: metrics-server/src/metrics_server/storage/__init__.py:21
    class Metric {
        <<from metrics>>
    }
    %% source: metrics-server/src/metrics_server/storage/schema.sql:3
    class metrics_table["metrics (table, schema.sql)"] {
        +id : bigint identity primary key
        +name : text not null
        +type : text not null
        +value : double precision not null
        +tags : jsonb not null
        +recorded_at : timestamptz not null
    }

    MetricStore <|.. PostgresMetricStore
    MetricStore ..> Metric : stores
    %% source: metrics-server/src/metrics_server/storage/__init__.py:39,55
    MetricStore ..> StorageUnavailable : open, store raise
    %% source: metrics-server/src/metrics_server/storage/schema.sql:2
    PostgresMetricStore --> metrics_table : creates in open, inserts in store

    %% source: .sources/components.yaml metrics_server.storage
    note for MetricStore "realizes: batch-is-atomic, duplicates-are-stored, timestamp-is-stored-in-utc"
```

### api (`metrics_server.api`, boundary concrete)

Responsibility: the FastAPI entry point; receives metrics and health
requests over HTTP, hands the metrics to the domain for validation and to
the store for writing, and maps every outcome to an HTTP response; the only
component that speaks HTTP (`src/api/__init__.py:1`).

```mermaid
classDiagram
    %% source: metrics-server/src/metrics_server/api/__init__.py:53,61
    class api_module["metrics_server.api"] {
        <<module>>
        +create_app(store: MetricStore) FastAPI
        +create_app_from_environment() FastAPI
    }
    %% source: metrics-server/src/metrics_server/api/__init__.py:48
    class MetricStore {
        <<interface, from storage>>
    }
    %% source: metrics-server/src/metrics_server/api/__init__.py:68
    class KeyError {
        <<exception>>
    }
    api_module ..> MetricStore : create_app takes
    api_module ..> KeyError : DATABASE_URL not set

    %% source: .sources/components.yaml metrics_server.api
    note for api_module "realizes: ingest-metrics, report-health, batch-shares-one-receipt-instant, stored-metrics-match-the-batch, invalid-metric-stores-nothing, ingesting-twice-stores-twice, storage-error-only-for-a-valid-batch"
```

HTTP contract (`src/api/__init__.py:11-40`). A metric object has `name`,
`type`, `value`, optional `tags` (an empty map when absent) and optional
`timestamp` (ISO 8601 with a time zone or offset). The batch is validated
in full before the store is called; the outcomes are exclusive and checked
in this order: a size error alone, then the violations, then the storage
error, which only a valid batch can get (`src/api/__init__.py:20-22`).

| Request | Status | Body | Spec id |
|---|---|---|---|
| `POST /metrics` (one metric object or an array) | 200 | `{"stored": <n>}` | `ingest-metrics` |
| | 400 | `{"error": "malformed-body"}`: not JSON, or neither object nor array | none |
| | 422 | `{"error": "empty-batch"}` | `ingest-empty-batch` |
| | 422 | `{"error": "batch-too-large"}` | `ingest-batch-too-large` |
| | 422 | `{"error": "invalid-metrics", "violations": [{"index", "field", "rule"}]}` | `ingest-invalid-metric` |
| | 503 | `{"error": "storage-unavailable"}` | `ingest-storage-unavailable` |
| `GET /health` | 200 | `{"status": "ready"}` | `report-health` |
| | 503 | `{"status": "not-ready"}` | `health-not-ready` |

Runtime (ford's report, `metrics-server/Dockerfile:14`,
`metrics-server/compose.yaml`): uvicorn starts
`metrics_server.api:create_app_from_environment` with `--factory` on port
8000; compose sets `DATABASE_URL` and runs `postgres:18`, and its
healthcheck calls `/health`.

## 5. Architecture rules

Source: `.sources/system.adl`. Fitness functions:
`metrics-server/tests/architecture/test_system.py`, run with
`toolchain test metrics-server/tests/architecture/test_system.py`
(ford's report: all 7 pass).

| Source | Assertion | Fitness test |
|---|---|---|
| `system.adl:ASSERT 1` | `ASSERT(CLASSES are only CONTAINED within COMPONENTS)` | `test_classes_are_only_contained_within_components` (`test_system.py:46`) |
| `system.adl:ASSERT 2` | `ASSERT(metrics has NO DEPENDENCY on {storage, api})` | `test_metrics_has_no_dependency_on_storage_or_api` (`test_system.py:50`) |
| `system.adl:ASSERT 3` | `ASSERT(storage has NO DEPENDENCY on api)` | `test_storage_has_no_dependency_on_api` (`test_system.py:55`) |
| `system.adl:ASSERT 4` | `ASSERT(metrics has NO DEPENDENCY on {fastapi, starlette, uvicorn, psycopg, psycopg_pool})` | `test_metrics_has_no_dependency_on_web_or_database_libraries` (`test_system.py:60`) |
| `system.adl:ASSERT 5` | `ASSERT(storage has NO DEPENDENCY on {fastapi, starlette, uvicorn})` | `test_storage_has_no_dependency_on_web_libraries` (`test_system.py:65`) |
| `system.adl:ASSERT 6` | `ASSERT(api has NO DEPENDENCY on {psycopg, psycopg_pool})` | `test_api_has_no_dependency_on_database_libraries` (`test_system.py:70`) |
| `system.adl:Metrics Server` (DEFINE tree) | every COMPONENT is defined | `test_every_component_is_defined` (`test_system.py:42`) |

## 6. Sequence diagrams of the iteration

### ingest-metrics

The order of the error checks follows `batch-size-error-takes-precedence`
and `storage-error-only-for-a-valid-batch`; the 400 branch is in the HTTP
contract and has no spec id.

```mermaid
sequenceDiagram
    %% source: spec.yaml ingest-metrics ("A client")
    actor Client
    %% source: .sources/components.yaml metrics_server.api
    participant api as api
    %% source: .sources/components.yaml metrics_server.metrics
    participant metrics as metrics
    %% source: .sources/components.yaml metrics_server.storage
    participant storage as storage (MetricStore)
    %% source: system.adl DESCRIPTION; storage/__init__.py:1
    participant pg as Postgres

    %% source: metrics-server/src/metrics_server/api/__init__.py:13
    Client->>api: POST /metrics (one metric object or an array)
    alt body not JSON, or neither object nor array
        %% source: metrics-server/src/metrics_server/api/__init__.py:25
        api-->>Client: 400 {"error": "malformed-body"}
    else body decoded
        %% source: metrics-server/src/metrics_server/api/__init__.py:42
        api->>api: take the instant of receipt once, in UTC
        %% source: metrics-server/src/metrics_server/metrics/__init__.py:119; api/__init__.py:3,20
        api->>metrics: parse_batch(items, received_at)
        alt batch empty (ingest-empty-batch, batch-size-error-takes-precedence)
            %% source: metrics/__init__.py:137; api/__init__.py:27
            metrics-->>api: raise EmptyBatch
            api-->>Client: 422 {"error": "empty-batch"}
        else more than 1000 metrics (ingest-batch-too-large, batch-size-error-takes-precedence)
            %% source: metrics/__init__.py:138-140; api/__init__.py:29
            metrics-->>api: raise BatchTooLarge (no item inspected)
            api-->>Client: 422 {"error": "batch-too-large"}
        else size valid, at least one invalid metric (ingest-invalid-metric)
            %% source: metrics/__init__.py:141-142; api/__init__.py:31
            metrics-->>api: raise InvalidMetrics(violations)
            api-->>Client: 422 {"error": "invalid-metrics", "violations": [...]}
        else batch valid in full (storage-error-only-for-a-valid-batch)
            %% source: metrics/__init__.py:134
            metrics-->>api: tuple[Metric, ...] in UTC, missing tags as an empty map
            %% source: metrics-server/src/metrics_server/storage/__init__.py:48; api/__init__.py:20
            api->>storage: store(metrics)
            %% source: metrics-server/src/metrics_server/storage/__init__.py:89
            storage->>pg: insert every metric in one transaction
            alt transaction did not commit (ingest-storage-unavailable)
                %% source: storage/__init__.py:91; api/__init__.py:34
                storage-->>api: raise StorageUnavailable
                api-->>Client: 503 {"error": "storage-unavailable"}
            else committed
                %% source: storage/__init__.py:48; api/__init__.py:24
                storage-->>api: n (int)
                api-->>Client: 200 {"stored": n}
            end
        end
    end
```

### report-health

```mermaid
sequenceDiagram
    %% source: spec.yaml report-health ("A caller"); api/__init__.py:40 (compose and the deployment)
    actor Caller
    %% source: .sources/components.yaml metrics_server.api
    participant api as api
    %% source: .sources/components.yaml metrics_server.storage
    participant storage as storage (MetricStore)
    %% source: system.adl DESCRIPTION
    participant pg as Postgres

    %% source: metrics-server/src/metrics_server/api/__init__.py:38
    Caller->>api: GET /health
    %% source: metrics-server/src/metrics_server/storage/__init__.py:59
    api->>storage: is_ready()
    %% source: metrics-server/src/metrics_server/storage/__init__.py:98
    storage->>pg: a query through the pool
    alt store can write metrics
        storage-->>api: true
        %% source: api/__init__.py:38
        api-->>Caller: 200 {"status": "ready"}
    else store cannot write metrics (health-not-ready)
        storage-->>api: false
        %% source: api/__init__.py:39
        api-->>Caller: 503 {"status": "not-ready"}
    end
```

### Startup and shutdown

Not a spec operation; drawn because `report-health` and `ingest-metrics`
depend on the store being open.

```mermaid
sequenceDiagram
    %% source: system.adl:Uvicorn; metrics-server/Dockerfile:14
    participant uvicorn as uvicorn
    %% source: .sources/components.yaml metrics_server.api
    participant api as api
    %% source: .sources/components.yaml metrics_server.storage
    participant storage as storage (PostgresMetricStore)
    participant pg as Postgres

    %% source: metrics-server/src/metrics_server/api/__init__.py:61
    uvicorn->>api: create_app_from_environment()
    alt DATABASE_URL not set
        %% source: api/__init__.py:68
        api-->>uvicorn: raise KeyError
    else DATABASE_URL set
        %% source: api/__init__.py:64-65; storage/__init__.py:67
        api->>storage: PostgresMetricStore(database_url)
        api-->>uvicorn: FastAPI application
        %% source: api/__init__.py:56
        uvicorn->>api: startup
        %% source: storage/__init__.py:75
        api->>storage: open()
        %% source: storage/__init__.py:76; schema.sql:2
        storage->>pg: open the pool, CREATE TABLE IF NOT EXISTS metrics
        alt Postgres unreachable or table not created
            %% source: storage/__init__.py:78
            storage-->>api: raise StorageUnavailable
        end
        %% source: api/__init__.py:56
        uvicorn->>api: shutdown
        %% source: storage/__init__.py:84
        api->>storage: close()
    end
```

## 7. Operations and properties

### metrics

| Id | Kind | Statement |
|---|---|---|
| `metric-value-is-finite` | invariant (Metric) | A metric value is a finite number, never NaN nor an infinity. |
| `counter-value-is-not-negative` | invariant (Metric) | The value of a counter metric is zero or greater. |
| `gauge-value-is-any-finite-number` | invariant (Metric) | The value of a gauge metric may be any finite number, negative included. |
| `histogram-value-is-one-observation` | invariant (Metric) | The value of a histogram metric is a single observation and may be any finite number. |
| `missing-timestamp-defaults-to-receipt` | invariant (Metric) | A metric received without a timestamp takes the instant at which the system received it. |
| `timestamp-carries-a-time-zone` | invariant (Metric) | A metric timestamp given without a time zone or offset is invalid. |
| `timestamp-is-stored-in-utc` | invariant (Metric) | A metric timestamp given with any offset is stored as the same instant expressed in UTC. |
| `timestamp-not-too-far-in-the-future` | invariant (Metric) | A metric timestamp more than five minutes after the instant of receipt is invalid. |
| `metric-name-has-dotted-segments` | invariant (MetricName) | A metric name consists of at least two segments separated by single dots, with no leading or trailing dot. |
| `metric-name-segment-characters` | invariant (MetricName) | Every segment of a metric name starts with a lowercase ASCII letter and contains only lowercase ASCII letters, digits and underscores. |
| `metric-name-length` | invariant (MetricName) | A metric name is at most 255 characters long. |
| `tags-may-be-empty` | invariant (Tags) | A metric may carry an empty tag map. |
| `tags-at-most-32` | invariant (Tags) | A tag map holds at most 32 entries. |
| `tag-key-length` | invariant (Tags) | A tag key is a string of 1 to 100 characters. |
| `tag-value-length` | invariant (Tags) | A tag value is a string of 1 to 255 characters. |
| `batch-is-not-empty` | invariant (Batch) | A batch holds at least one metric. |
| `batch-at-most-1000` | invariant (Batch) | A batch holds at most 1000 metrics. |
| `batch-shares-one-receipt-instant` | relation rule (Batch-Metric) | Every metric of a batch received without a timestamp takes the same instant of receipt. |
| `valid-names-are-accepted` | property, invariant | A metric carrying the name satisfies every MetricName invariant and is accepted. |
| `counter-rejects-negative-values` | property, invariant | A counter metric with the value is invalid, while a gauge or histogram metric with the same value is valid. |
| `offset-does-not-change-the-instant` | property, metamorphic | Ingesting the metric with its timestamp expressed in the given offset stores the same UTC instant as ingesting it with the timestamp expressed in UTC. |
| `missing-tags-default-to-empty` | invariant (Tags) | A metric received without tags is accepted and stored with an empty tag map. |
| `batch-size-error-takes-precedence` | constraint | A batch that is empty or holds more than 1000 metrics is reported only with its size error, whether or not any of its metrics is invalid. |

### storage

| Id | Kind | Statement |
|---|---|---|
| `batch-is-atomic` | constraint | Either every metric of a batch is stored or none is. |
| `duplicates-are-stored` | constraint | A metric identical to one already stored is stored again as a separate sample. |
| `timestamp-is-stored-in-utc` | invariant (Metric) | A metric timestamp given with any offset is stored as the same instant expressed in UTC. |

### api

| Id | Kind | Statement |
|---|---|---|
| `ingest-metrics` | operation | A client sends one metric or a batch of metrics to be stored. |
| `report-health` | operation | A caller asks whether the system is ready to receive metrics. |
| `batch-shares-one-receipt-instant` | relation rule (Batch-Metric) | Every metric of a batch received without a timestamp takes the same instant of receipt. |
| `stored-metrics-match-the-batch` | property, model | After ingesting the batch, the newly stored metrics equal the batch as a multiset, with each missing timestamp replaced by the instant of receipt. |
| `invalid-metric-stores-nothing` | property, invariant | After ingesting the batch, the set of stored metrics is unchanged. |
| `ingesting-twice-stores-twice` | property, metamorphic | Ingesting the same batch twice stores every metric of the batch exactly twice. |
| `storage-error-only-for-a-valid-batch` | constraint | The client learns that the storage is unavailable only for a batch whose size and metrics are all valid. |

## 8. Open points

* `create_app` opens the store at startup, and `open` raises
  `StorageUnavailable`; the interface does not say what the application does
  then (whether it fails to start or starts not ready). Sources:
  `src/api/__init__.py:56`, `src/storage/__init__.py:39`.
* `ASSERT(CLASSES are only CONTAINED within COMPONENTS)` is checked with
  `allow=[SYSTEM]`, so the system package itself may also contain classes.
  Sources: `system.adl:ASSERT 1`, `test_system.py:47`.
* The LIBRARYs Starlette and psycopg have no stated use by any component
  (the interfaces name FastAPI, uvicorn and the psycopg connection pool):
  they are drawn without relationships. Sources: `system.adl:Starlette`,
  `system.adl:psycopg`, `src/storage/__init__.py:65`.
* The Docker images were not built and compose was never started; the image
  tag `ghcr.io/astral-sh/uv:0.9` was not checked. Source: ford's report.
* Choices hughes made under the user's delegation, flagged for review:
  `batch-is-atomic`, the batch limits, `duplicates-are-stored`,
  `timestamp-not-too-far-in-the-future`, `timestamp-carries-a-time-zone`,
  `counter-value-is-not-negative`, the tag limits, no events,
  `missing-tags-default-to-empty`, `batch-size-error-takes-precedence`,
  `storage-error-only-for-a-valid-batch`. Source: hughes's reports.

## 9. Changelog

| Time | Event | Change |
|---|---|---|
| 2026-10-24 15:33 CEST | Check on resume (step 4, unclebob on metrics) | Sources unchanged, `spec-check --stage realization` ok; the interface of metrics is unchanged, its declarations moved 3 lines down: citations in sections 4 and 6 updated; HEAD `7576269`. |
| 2026-10-24 09:16 CEST | User decision (via kent) | The request shape codes, the rejection of unknown fields and the 400 stay a detail of the HTTP contract, not domain rules: noted in section 4, open point closed. |
| 2026-10-24 09:13 CEST | SOURCES_CHANGED ford (alignment, `e0ccdd7`) | metrics realizes `missing-tags-default-to-empty` and `batch-size-error-takes-precedence`, api realizes `storage-error-only-for-a-valid-batch`; `tags` optional in `parse_batch` and the HTTP contract; ingest sequence redrawn with the precedence of size errors and the storage call only for a batch valid in full; line citations updated; table of unrealized ids removed; open points on unrealized ids, required tags and error order closed. |
| 2026-10-24 09:12 CEST | SOURCES_CHANGED hughes (correction) | Domain model: `Metric.tags` optional (Tags 0..1), new type of `Metric.timestamp`, notes for `missing-tags-default-to-empty`, `batch-size-error-takes-precedence`, `storage-error-only-for-a-valid-batch`; ingest sequence ordered by the new constraints; table of unrealized ids; open points on tags and error order closed in the spec, replaced by the gap between spec and interface. |
| 2026-10-24 09:12 CEST | SOURCES_CHANGED ford | Sections 4 to 7 drawn from `system.adl`, `components.yaml` and the interfaces: components metrics, storage, api with HTTP contract; six ADL assertions with their fitness tests; sequences of `ingest-metrics`, `report-health`, startup and shutdown; tables per component. C4 workspace: Metrics Server system and container, three components, five libraries, Postgres, Client and Caller, relationships from the interfaces. |
| 2026-10-24 09:04 CEST | SOURCES_CHANGED hughes | Domain model drawn from `spec.yaml`: value objects Metric, MetricName, Tags, Batch, relation Batch-Metric, invariants and constraints as notes; tables of operations, errors and properties. Workspace unchanged (no ADL). |
| 2026-10-24 09:02 CEST | LAUNCH (kent's base-branch check) | Base branch confirmed as `master`; the open point on `main` closed. |
| 2026-10-24 09:02 CEST | LAUNCH | First version: header and scope from the shopping list; sections 3 to 7 wait for hughes and ford; empty C4 workspace. |
