// C4 model of the metrics-server branch, from .sources/system.adl,
// .sources/components.yaml and the interfaces in metrics-server/src/metrics_server/.
workspace "metrics-server" "HTTP server that receives metrics and stores them in Postgres." {

    model {
        client = person "Client" "Sends one metric or a batch of metrics to be stored." {
            properties {
                "source" "spec.yaml:ingest-metrics"
            }
        }
        caller = person "Health caller" "Asks whether the system is ready to receive metrics; compose and the deployment wait on it." {
            properties {
                "source" "spec.yaml:report-health; metrics-server/src/metrics_server/api/__init__.py:40"
            }
        }

        postgres = softwareSystem "Postgres" "Stores the metrics; one row per received sample in the table metrics." {
            tags "External"
            properties {
                "source" "system.adl:DESCRIPTION; metrics-server/src/metrics_server/storage/__init__.py:1; metrics-server/src/metrics_server/storage/schema.sql:3"
            }
        }

        metricsServer = softwareSystem "Metrics Server" "An HTTP server that receives one metric or a batch of metrics per request, validates them against the domain rules and stores them in Postgres, with a health check." {
            properties {
                "source" "system.adl:Metrics Server"
            }

            app = container "Metrics Server" "The single deployable unit of the system: the ADL defines no SERVICE." "Python 3.12, FastAPI, uvicorn" {
                properties {
                    "source" "system.adl:Metrics Server; FORD_DONE report; metrics-server/Dockerfile:14"
                }

                metrics = component "Metrics" "The metric, its name, its tags and the batch a request carries, and the rules that decide whether a batch may be stored; pure, no I/O." "metrics_server.metrics" {
                    properties {
                        "source" "system.adl:Metrics; components.yaml:metrics_server.metrics; metrics-server/src/metrics_server/metrics/__init__.py:1"
                    }
                }
                storage = component "Storage" "Writes validated metrics to Postgres behind the MetricStore interface; the only component that talks to the database." "metrics_server.storage.MetricStore" {
                    properties {
                        "source" "system.adl:Storage; components.yaml:metrics_server.storage; metrics-server/src/metrics_server/storage/__init__.py:1"
                    }
                }
                api = component "HTTP API" "The FastAPI entry point: receives metrics and health requests, hands the metrics to the domain for validation and to the store for writing, and maps every outcome to an HTTP response; the only component that speaks HTTP." "metrics_server.api" {
                    properties {
                        "source" "system.adl:HTTP API; components.yaml:metrics_server.api; metrics-server/src/metrics_server/api/__init__.py:1"
                    }
                }

                fastapi = component "FastAPI" "Library." "fastapi" {
                    tags "Library"
                    properties {
                        "source" "system.adl:FastAPI"
                    }
                }
                starlette = component "Starlette" "Library." "starlette" {
                    tags "Library"
                    properties {
                        "source" "system.adl:Starlette"
                    }
                }
                uvicorn = component "Uvicorn" "Library." "uvicorn" {
                    tags "Library"
                    properties {
                        "source" "system.adl:Uvicorn"
                    }
                }
                psycopg = component "psycopg" "Library." "psycopg" {
                    tags "Library"
                    properties {
                        "source" "system.adl:psycopg"
                    }
                }
                psycopgPool = component "psycopg pool" "Library." "psycopg_pool" {
                    tags "Library"
                    properties {
                        "source" "system.adl:psycopg pool"
                    }
                }
            }
        }

        client -> api "Sends metrics" "POST /metrics, HTTP/JSON" {
            properties {
                "source" "metrics-server/src/metrics_server/api/__init__.py:13"
            }
        }
        caller -> api "Asks for readiness" "GET /health, HTTP/JSON" {
            properties {
                "source" "metrics-server/src/metrics_server/api/__init__.py:38"
            }
        }
        uvicorn -> api "Starts the application" "create_app_from_environment, --factory" {
            properties {
                "source" "metrics-server/src/metrics_server/api/__init__.py:61; metrics-server/Dockerfile:14"
            }
        }
        api -> fastapi "Builds the application on" "FastAPI" {
            properties {
                "source" "metrics-server/src/metrics_server/api/__init__.py:46"
            }
        }
        api -> metrics "Validates a batch" "parse_batch" {
            properties {
                "source" "metrics-server/src/metrics_server/api/__init__.py:3; metrics-server/src/metrics_server/metrics/__init__.py:119"
            }
        }
        api -> storage "Writes a valid batch, asks for readiness, opens and closes the store" "MetricStore" {
            properties {
                "source" "metrics-server/src/metrics_server/api/__init__.py:48,53,56"
            }
        }
        storage -> metrics "Stores Metric values" "Metric" {
            properties {
                "source" "metrics-server/src/metrics_server/storage/__init__.py:21"
            }
        }
        storage -> psycopgPool "Connects through a connection pool" "psycopg_pool" {
            properties {
                "source" "metrics-server/src/metrics_server/storage/__init__.py:65"
            }
        }
        storage -> postgres "Creates the table, inserts metrics in one transaction, checks readiness" "SQL" {
            properties {
                "source" "metrics-server/src/metrics_server/storage/__init__.py:76,89,98"
            }
        }
    }

    views {
        systemContext metricsServer "SystemContext" {
            include *
            autoLayout
        }
        container metricsServer "Containers" {
            include *
            autoLayout
        }
        component app "Components" {
            include *
            autoLayout
        }
        styles {
            element "Library" {
                shape Component
                background #dddddd
            }
            element "External" {
                background #999999
            }
            element "Person" {
                shape Person
            }
        }
    }

    configuration {
        scope softwaresystem
    }

}
