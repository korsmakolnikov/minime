"""Metrics: the domain of the metrics server.

The metric, its name, its tags and the batch a request carries, and the
rules that decide whether a batch may be stored. Pure: no I/O, no web or
database library.

Boundary: concrete. Callers use this module for real; its tests need no
double, since it has no collaborator and takes the instant of receipt as
an argument.

The public interface is ``parse_batch``: it turns the decoded JSON of a
request into validated ``Metric`` values, or raises a subclass of
``InvalidBatch`` that says why nothing may be stored.
"""

import math
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from enum import StrEnum

__all__ = [
    "BatchTooLarge",
    "EmptyBatch",
    "InvalidBatch",
    "InvalidMetrics",
    "Metric",
    "MetricType",
    "Violation",
    "parse_batch",
]

_MAX_BATCH_SIZE = 1000
_MAX_NAME_LENGTH = 255
_MAX_TAGS = 32
_MAX_TAG_KEY_LENGTH = 100
_MAX_TAG_VALUE_LENGTH = 255
_FUTURE_LIMIT = timedelta(minutes=5)
_REQUIRED_FIELDS = ("name", "type", "value")
_FIELDS = frozenset({*_REQUIRED_FIELDS, "tags", "timestamp"})
_SEGMENT = re.compile("[a-z][a-z0-9_]*")


class MetricType(StrEnum):
    """The kind of measurement a metric is."""

    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"


_TYPES = tuple(MetricType)


@dataclass(frozen=True)
class Metric:
    """One validated sample, ready to be stored.

    Only ``parse_batch`` builds it, so every field already satisfies the
    invariants of Metric, MetricName and Tags.

    Attributes:
        name: the metric name in the ``domain.subject_unit`` style.
        type: counter, gauge or histogram.
        value: a finite number; zero or greater for a counter.
        tags: string keys to string values; possibly empty, and empty when
            the client sent none.
        timestamp: an aware datetime in UTC; the instant of receipt when the
            client sent none.
    """

    name: str
    type: MetricType
    value: float
    tags: Mapping[str, str]
    timestamp: datetime


@dataclass(frozen=True)
class Violation:
    """One rule an invalid metric of a batch breaks.

    Attributes:
        index: the zero-based position of the metric in the batch.
        field: the field the rule is about (``name``, ``type``, ``value``,
            ``tags``, ``timestamp``, or the unknown field's own name); None
            when the item is not a JSON object at all.
        rule: the id of the spec invariant the metric breaks (for example
            ``metric-name-length``, ``counter-value-is-not-negative``,
            ``timestamp-carries-a-time-zone``), or one of the shape codes:
            ``not-an-object`` (the item is not a JSON object),
            ``field-missing`` (a required field is absent),
            ``field-unknown`` (a field the metric does not have),
            ``field-invalid`` (a value of the wrong JSON type, a type other
            than counter, gauge or histogram, a timestamp that is not an
            ISO 8601 string).
    """

    index: int
    field: str | None
    rule: str


class InvalidBatch(Exception):
    """The batch cannot be stored; nothing of it may be written."""


class EmptyBatch(InvalidBatch):
    """The batch holds no metrics (spec: ingest-empty-batch)."""


class BatchTooLarge(InvalidBatch):
    """The batch holds more than 1000 metrics (spec: ingest-batch-too-large)."""


class InvalidMetrics(InvalidBatch):
    """At least one metric breaks a rule (spec: ingest-invalid-metric).

    ``violations`` lists every invalid metric of the batch, ordered by index,
    with at least one entry per invalid metric and one entry per broken rule.
    """

    violations: tuple[Violation, ...]

    def __init__(self, violations: Sequence[Violation]) -> None:
        super().__init__(violations)
        self.violations = tuple(violations)


def parse_batch(items: Sequence[object], received_at: datetime) -> tuple[Metric, ...]:
    """Validate the items of a request and return them as metrics, in order.

    Args:
        items: the decoded JSON items of the batch, one per metric; a request
            carrying a single metric passes a sequence of one. Each item is
            expected to be an object with ``name``, ``type`` and ``value``,
            and optionally ``tags`` (an object of strings; an empty map when
            absent) and ``timestamp`` (an ISO 8601 string with a time zone or
            offset).
        received_at: the aware UTC instant at which the request arrived; it
            becomes the timestamp of every metric sent without one, and is
            the reference for the five-minute future limit.

    Returns:
        One metric per item, in the order of ``items``, timestamps in UTC.

    Raises:
        EmptyBatch: ``items`` is empty.
        BatchTooLarge: ``items`` holds more than 1000 items, whether or not
            any of them is invalid: the size error takes precedence and no
            item is inspected.
        InvalidMetrics: the size is valid and at least one item is not a
            valid metric.
    """
    if len(items) > _MAX_BATCH_SIZE:
        raise BatchTooLarge()
    if not items:
        raise EmptyBatch()
    violations = [
        violation
        for index, item in enumerate(items)
        for violation in _violations(index, item, received_at)
    ]
    if violations:
        raise InvalidMetrics(violations)
    return tuple(_to_metric(item, received_at) for item in items)


def _violations(index, item, received_at):
    if not isinstance(item, Mapping):
        yield Violation(index, None, "not-an-object")
        return
    missing = [field for field in _REQUIRED_FIELDS if field not in item]
    if missing:
        for field in missing:
            yield Violation(index, field, "field-missing")
        return
    for field in item:
        if field not in _FIELDS:
            yield Violation(index, field, "field-unknown")
    if item["type"] not in _TYPES:
        yield Violation(index, "type", "field-invalid")
    yield from _name_violations(index, item["name"])
    yield from _tag_violations(index, item.get("tags", {}))
    if "timestamp" in item:
        yield from _timestamp_violations(index, item["timestamp"], received_at)
    yield from _value_violations(index, item["type"], item["value"])


def _name_violations(index, name):
    if not isinstance(name, str):
        yield Violation(index, "name", "field-invalid")
        return
    segments = name.split(".")
    if len(segments) < 2 or "" in segments:
        yield Violation(index, "name", "metric-name-has-dotted-segments")
    elif not all(_SEGMENT.fullmatch(segment) for segment in segments):
        yield Violation(index, "name", "metric-name-segment-characters")
    if len(name) > _MAX_NAME_LENGTH:
        yield Violation(index, "name", "metric-name-length")


def _tag_violations(index, tags):
    if not isinstance(tags, Mapping) or not all(isinstance(value, str) for value in tags.values()):
        yield Violation(index, "tags", "field-invalid")
        return
    if len(tags) > _MAX_TAGS:
        yield Violation(index, "tags", "tags-at-most-32")
    if not all(1 <= len(key) <= _MAX_TAG_KEY_LENGTH for key in tags):
        yield Violation(index, "tags", "tag-key-length")
    if not all(1 <= len(value) <= _MAX_TAG_VALUE_LENGTH for value in tags.values()):
        yield Violation(index, "tags", "tag-value-length")


def _timestamp_violations(index, text, received_at):
    try:
        timestamp = datetime.fromisoformat(text)
    except (TypeError, ValueError):
        yield Violation(index, "timestamp", "field-invalid")
        return
    if timestamp.tzinfo is None:
        yield Violation(index, "timestamp", "timestamp-carries-a-time-zone")
    elif timestamp > received_at + _FUTURE_LIMIT:
        yield Violation(index, "timestamp", "timestamp-not-too-far-in-the-future")


def _value_violations(index, type_, value):
    if isinstance(value, bool) or not isinstance(value, int | float):
        yield Violation(index, "value", "field-invalid")
        return
    if not math.isfinite(value):
        yield Violation(index, "value", "metric-value-is-finite")
    if type_ == MetricType.COUNTER and value < 0:
        yield Violation(index, "value", "counter-value-is-not-negative")


def _to_metric(item, received_at):
    return Metric(
        name=item["name"],
        type=MetricType(item["type"]),
        value=item["value"],
        tags=item.get("tags", {}),
        timestamp=(
            datetime.fromisoformat(item["timestamp"]).astimezone(UTC)
            if "timestamp" in item
            else received_at
        ),
    )
