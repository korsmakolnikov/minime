import math
from datetime import UTC, datetime, timedelta, timezone

import pytest
from hypothesis import given
from hypothesis import strategies as st
from support.strategies import metric_names, utc_instants, utc_offsets

from metrics_server.metrics import (
    BatchTooLarge,
    EmptyBatch,
    InvalidMetrics,
    MetricType,
    Violation,
    parse_batch,
)

RECEIVED_AT = datetime(2026, 10, 24, 12, 0, 0, tzinfo=UTC)


def metric_item(**fields: object) -> dict[str, object]:
    return {"name": "cpu.load", "type": "gauge", "value": 1.0, **fields}


def tag_map(count: int) -> dict[str, str]:
    return {f"k{number}": "v" for number in range(count)}


def violations_of(items: list[object]) -> tuple[Violation, ...]:
    with pytest.raises(InvalidMetrics) as error:
        parse_batch(items, RECEIVED_AT)
    return error.value.violations


def test_an_empty_batch_is_rejected() -> None:
    # spec: batch-is-not-empty
    with pytest.raises(EmptyBatch):
        parse_batch([], RECEIVED_AT)


def test_a_batch_of_1001_metrics_is_too_large() -> None:
    # spec: batch-at-most-1000
    with pytest.raises(BatchTooLarge):
        parse_batch([metric_item()] * 1001, RECEIVED_AT)


def test_a_too_large_batch_of_invalid_items_reports_only_its_size() -> None:
    # spec: batch-size-error-takes-precedence
    with pytest.raises(BatchTooLarge):
        parse_batch([42] * 1001, RECEIVED_AT)


def test_a_batch_of_1000_metrics_is_accepted() -> None:
    # spec: batch-at-most-1000
    assert len(parse_batch([metric_item()] * 1000, RECEIVED_AT)) == 1000


def test_an_item_that_is_not_an_object_is_invalid() -> None:
    # contract: Violation not-an-object
    assert violations_of([42]) == (Violation(0, None, "not-an-object"),)


def test_a_list_item_is_not_an_object() -> None:
    # contract: Violation not-an-object
    assert violations_of([metric_item(), ["cpu.load"]]) == (Violation(1, None, "not-an-object"),)


def test_an_item_without_a_name_is_invalid() -> None:
    # contract: Violation field-missing
    assert violations_of([{"type": "gauge", "value": 1.0}]) == (
        Violation(0, "name", "field-missing"),
    )


def test_an_item_without_a_value_is_invalid() -> None:
    # contract: Violation field-missing
    assert violations_of([{"name": "cpu.load", "type": "gauge"}]) == (
        Violation(0, "value", "field-missing"),
    )


def test_an_empty_object_misses_every_required_field() -> None:
    # contract: Violation field-missing
    assert violations_of([{}]) == (
        Violation(0, "name", "field-missing"),
        Violation(0, "type", "field-missing"),
        Violation(0, "value", "field-missing"),
    )


def test_an_unknown_field_is_invalid() -> None:
    # contract: Violation field-unknown
    assert violations_of([metric_item(unit="s")]) == (Violation(0, "unit", "field-unknown"),)


def test_every_unknown_field_is_reported() -> None:
    # contract: Violation field-unknown
    assert violations_of([metric_item(host="web-1", Name="cpu.load")]) == (
        Violation(0, "host", "field-unknown"),
        Violation(0, "Name", "field-unknown"),
    )


def test_a_type_other_than_the_three_kinds_is_invalid() -> None:
    # contract: Violation field-invalid
    assert violations_of([metric_item(type="summary")]) == (Violation(0, "type", "field-invalid"),)


def test_a_capitalised_type_is_invalid() -> None:
    # contract: Violation field-invalid
    assert violations_of([metric_item(type="Gauge")]) == (Violation(0, "type", "field-invalid"),)


def test_a_string_value_is_invalid() -> None:
    # contract: Violation field-invalid
    assert violations_of([metric_item(value="1")]) == (Violation(0, "value", "field-invalid"),)


def test_a_boolean_value_is_invalid() -> None:
    # contract: Violation field-invalid
    assert violations_of([metric_item(value=True)]) == (Violation(0, "value", "field-invalid"),)


def test_a_numeric_name_is_invalid() -> None:
    # contract: Violation field-invalid
    assert violations_of([metric_item(name=42)]) == (Violation(0, "name", "field-invalid"),)


def test_a_null_name_is_invalid() -> None:
    # contract: Violation field-invalid
    assert violations_of([metric_item(name=None)]) == (Violation(0, "name", "field-invalid"),)


def test_tags_sent_as_a_string_are_invalid() -> None:
    # contract: Violation field-invalid
    assert violations_of([metric_item(tags="host=web-1")]) == (
        Violation(0, "tags", "field-invalid"),
    )


def test_tags_sent_as_a_list_are_invalid() -> None:
    # contract: Violation field-invalid
    assert violations_of([metric_item(tags=[["host", "web-1"]])]) == (
        Violation(0, "tags", "field-invalid"),
    )


def test_a_numeric_tag_value_is_invalid() -> None:
    # contract: Violation field-invalid
    assert violations_of([metric_item(tags={"port": 8080})]) == (
        Violation(0, "tags", "field-invalid"),
    )


def test_a_null_tag_value_is_invalid() -> None:
    # contract: Violation field-invalid
    assert violations_of([metric_item(tags={"host": None})]) == (
        Violation(0, "tags", "field-invalid"),
    )


def test_a_timestamp_that_is_not_iso_8601_is_invalid() -> None:
    # contract: Violation field-invalid
    assert violations_of([metric_item(timestamp="yesterday")]) == (
        Violation(0, "timestamp", "field-invalid"),
    )


def test_a_timestamp_with_month_13_is_invalid() -> None:
    # contract: Violation field-invalid
    assert violations_of([metric_item(timestamp="2026-13-01T00:00:00Z")]) == (
        Violation(0, "timestamp", "field-invalid"),
    )


def test_a_numeric_timestamp_is_invalid() -> None:
    # contract: Violation field-invalid
    assert violations_of([metric_item(timestamp=1792843200)]) == (
        Violation(0, "timestamp", "field-invalid"),
    )


def test_a_gauge_keeps_a_negative_value() -> None:
    # spec: gauge-value-is-any-finite-number
    (metric,) = parse_batch([metric_item(value=-3.5)], RECEIVED_AT)
    assert metric.value == -3.5


def test_a_histogram_is_one_observation_of_any_finite_value() -> None:
    # spec: histogram-value-is-one-observation
    (metric,) = parse_batch([metric_item(type="histogram", value=-2.5)], RECEIVED_AT)
    assert (metric.type, metric.value) == (MetricType.HISTOGRAM, -2.5)


def test_a_counter_with_a_negative_value_is_invalid() -> None:
    # spec: counter-value-is-not-negative
    assert violations_of([metric_item(type="counter", value=-1.0)]) == (
        Violation(0, "value", "counter-value-is-not-negative"),
    )


def test_a_nan_value_is_invalid() -> None:
    # spec: metric-value-is-finite
    assert violations_of([metric_item(value=math.nan)]) == (
        Violation(0, "value", "metric-value-is-finite"),
    )


def test_an_infinite_value_is_invalid() -> None:
    # spec: metric-value-is-finite
    assert violations_of([metric_item(value=math.inf)]) == (
        Violation(0, "value", "metric-value-is-finite"),
    )


@given(value=st.floats(max_value=0.0, exclude_max=True, allow_nan=False, allow_infinity=False))
def test_a_negative_value_is_invalid_only_for_a_counter(value: float) -> None:
    # spec: counter-rejects-negative-values
    assert violations_of([metric_item(type="counter", value=value)]) == (
        Violation(0, "value", "counter-value-is-not-negative"),
    )
    parse_batch(
        [metric_item(type="gauge", value=value), metric_item(type="histogram", value=value)],
        RECEIVED_AT,
    )


def test_a_violation_names_the_position_of_the_invalid_metric() -> None:
    # spec: ingest-invalid-metric
    assert violations_of([metric_item(), metric_item(type="counter", value=-1.0)]) == (
        Violation(1, "value", "counter-value-is-not-negative"),
    )


def test_every_invalid_metric_of_a_batch_is_reported() -> None:
    # spec: ingest-invalid-metric
    negative_counter = metric_item(type="counter", value=-1.0)
    assert violations_of([negative_counter, metric_item(), negative_counter]) == (
        Violation(0, "value", "counter-value-is-not-negative"),
        Violation(2, "value", "counter-value-is-not-negative"),
    )


@given(name=metric_names())
def test_every_valid_name_is_accepted(name: str) -> None:
    # spec: valid-names-are-accepted
    (metric,) = parse_batch([metric_item(name=name)], RECEIVED_AT)
    assert metric.name == name


def test_a_name_of_one_segment_is_invalid() -> None:
    # spec: metric-name-has-dotted-segments
    assert violations_of([metric_item(name="cpu")]) == (
        Violation(0, "name", "metric-name-has-dotted-segments"),
    )


def test_a_name_with_a_double_dot_is_invalid() -> None:
    # spec: metric-name-has-dotted-segments
    assert violations_of([metric_item(name="cpu..load")]) == (
        Violation(0, "name", "metric-name-has-dotted-segments"),
    )


def test_a_name_with_a_leading_dot_is_invalid() -> None:
    # spec: metric-name-has-dotted-segments
    assert violations_of([metric_item(name=".cpu.load")]) == (
        Violation(0, "name", "metric-name-has-dotted-segments"),
    )


def test_a_name_with_a_trailing_dot_is_invalid() -> None:
    # spec: metric-name-has-dotted-segments
    assert violations_of([metric_item(name="cpu.load.")]) == (
        Violation(0, "name", "metric-name-has-dotted-segments"),
    )


def test_a_name_segment_starting_with_a_digit_is_invalid() -> None:
    # spec: metric-name-segment-characters
    assert violations_of([metric_item(name="cpu.1load")]) == (
        Violation(0, "name", "metric-name-segment-characters"),
    )


def test_a_name_with_an_uppercase_letter_is_invalid() -> None:
    # spec: metric-name-segment-characters
    assert violations_of([metric_item(name="cpu.Load")]) == (
        Violation(0, "name", "metric-name-segment-characters"),
    )


def test_a_name_of_256_characters_is_invalid() -> None:
    # spec: metric-name-length
    assert violations_of([metric_item(name="cpu." + "a" * 252)]) == (
        Violation(0, "name", "metric-name-length"),
    )


def test_a_name_of_1000_characters_is_invalid() -> None:
    # spec: metric-name-length
    assert violations_of([metric_item(name="cpu." + "a" * 996)]) == (
        Violation(0, "name", "metric-name-length"),
    )


def test_a_name_of_255_characters_is_accepted() -> None:
    # spec: metric-name-length
    name = "cpu." + "a" * 251
    (metric,) = parse_batch([metric_item(name=name)], RECEIVED_AT)
    assert metric.name == name


def test_a_metric_keeps_its_tags() -> None:
    (metric,) = parse_batch([metric_item(tags={"host": "web-1"})], RECEIVED_AT)
    assert metric.tags == {"host": "web-1"}


def test_a_metric_sent_without_tags_has_an_empty_tag_map() -> None:
    # spec: missing-tags-default-to-empty
    (metric,) = parse_batch([metric_item()], RECEIVED_AT)
    assert metric.tags == {}


def test_a_metric_may_carry_an_empty_tag_map() -> None:
    # spec: tags-may-be-empty
    (metric,) = parse_batch([metric_item(tags={})], RECEIVED_AT)
    assert metric.tags == {}


def test_a_metric_with_33_tags_is_invalid() -> None:
    # spec: tags-at-most-32
    assert violations_of([metric_item(tags=tag_map(33))]) == (
        Violation(0, "tags", "tags-at-most-32"),
    )


def test_a_metric_with_100_tags_is_invalid() -> None:
    # spec: tags-at-most-32
    assert violations_of([metric_item(tags=tag_map(100))]) == (
        Violation(0, "tags", "tags-at-most-32"),
    )


def test_a_metric_with_32_tags_is_accepted() -> None:
    # spec: tags-at-most-32
    (metric,) = parse_batch([metric_item(tags=tag_map(32))], RECEIVED_AT)
    assert len(metric.tags) == 32


def test_an_empty_tag_key_is_invalid() -> None:
    # spec: tag-key-length
    assert violations_of([metric_item(tags={"": "v"})]) == (Violation(0, "tags", "tag-key-length"),)


def test_a_tag_key_of_101_characters_is_invalid() -> None:
    # spec: tag-key-length
    assert violations_of([metric_item(tags={"k" * 101: "v"})]) == (
        Violation(0, "tags", "tag-key-length"),
    )


def test_a_tag_key_of_150_characters_is_invalid() -> None:
    # spec: tag-key-length
    assert violations_of([metric_item(tags={"x" * 150: "v"})]) == (
        Violation(0, "tags", "tag-key-length"),
    )


def test_a_tag_key_of_100_characters_is_accepted() -> None:
    # spec: tag-key-length
    (metric,) = parse_batch([metric_item(tags={"k" * 100: "v"})], RECEIVED_AT)
    assert metric.tags == {"k" * 100: "v"}


def test_an_empty_tag_value_is_invalid() -> None:
    # spec: tag-value-length
    assert violations_of([metric_item(tags={"k": ""})]) == (
        Violation(0, "tags", "tag-value-length"),
    )


def test_a_tag_value_of_256_characters_is_invalid() -> None:
    # spec: tag-value-length
    assert violations_of([metric_item(tags={"k": "v" * 256})]) == (
        Violation(0, "tags", "tag-value-length"),
    )


def test_a_tag_value_of_400_characters_is_invalid() -> None:
    # spec: tag-value-length
    assert violations_of([metric_item(tags={"k": "x" * 400})]) == (
        Violation(0, "tags", "tag-value-length"),
    )


def test_a_tag_value_of_255_characters_is_accepted() -> None:
    # spec: tag-value-length
    (metric,) = parse_batch([metric_item(tags={"k": "v" * 255})], RECEIVED_AT)
    assert metric.tags == {"k": "v" * 255}


def test_a_metric_keeps_its_timestamp() -> None:
    (metric,) = parse_batch([metric_item(timestamp="2026-10-24T11:30:00Z")], RECEIVED_AT)
    assert metric.timestamp == datetime(2026, 10, 24, 11, 30, tzinfo=UTC)


def test_a_metric_without_a_timestamp_takes_the_instant_of_receipt() -> None:
    # spec: missing-timestamp-defaults-to-receipt
    (metric,) = parse_batch([metric_item()], RECEIVED_AT)
    assert metric.timestamp == RECEIVED_AT


def test_every_unstamped_metric_of_a_batch_shares_the_instant_of_receipt() -> None:
    # spec: batch-shares-one-receipt-instant
    metrics = parse_batch([metric_item(), metric_item(type="counter")], RECEIVED_AT)
    assert [metric.timestamp for metric in metrics] == [RECEIVED_AT, RECEIVED_AT]


def test_a_timestamp_without_a_time_zone_is_invalid() -> None:
    # spec: timestamp-carries-a-time-zone
    assert violations_of([metric_item(timestamp="2026-10-24T11:30:00")]) == (
        Violation(0, "timestamp", "timestamp-carries-a-time-zone"),
    )


def test_a_date_only_timestamp_is_invalid() -> None:
    # spec: timestamp-carries-a-time-zone
    assert violations_of([metric_item(timestamp="2026-01-01")]) == (
        Violation(0, "timestamp", "timestamp-carries-a-time-zone"),
    )


def test_a_timestamp_just_over_five_minutes_ahead_is_invalid() -> None:
    # spec: timestamp-not-too-far-in-the-future
    assert violations_of([metric_item(timestamp="2026-10-24T12:05:01Z")]) == (
        Violation(0, "timestamp", "timestamp-not-too-far-in-the-future"),
    )


def test_a_timestamp_a_year_ahead_is_invalid() -> None:
    # spec: timestamp-not-too-far-in-the-future
    assert violations_of([metric_item(timestamp="2027-10-24T12:00:00+02:00")]) == (
        Violation(0, "timestamp", "timestamp-not-too-far-in-the-future"),
    )


def test_a_timestamp_exactly_five_minutes_ahead_is_accepted() -> None:
    # spec: timestamp-not-too-far-in-the-future
    (metric,) = parse_batch([metric_item(timestamp="2026-10-24T12:05:00Z")], RECEIVED_AT)
    assert metric.timestamp == RECEIVED_AT + timedelta(minutes=5)


def test_a_timestamp_with_an_offset_is_stored_in_utc() -> None:
    # spec: timestamp-is-stored-in-utc
    (metric,) = parse_batch([metric_item(timestamp="2026-10-24T13:30:00+02:00")], RECEIVED_AT)
    assert (metric.timestamp, metric.timestamp.tzinfo) == (
        datetime(2026, 10, 24, 11, 30, tzinfo=UTC),
        UTC,
    )


@given(
    instant=utc_instants(since=datetime(2000, 1, 1, tzinfo=UTC), until=RECEIVED_AT),
    offset=utc_offsets(lowest=timedelta(hours=-12), highest=timedelta(hours=14)),
)
def test_the_offset_of_a_timestamp_does_not_change_its_instant(
    instant: datetime, offset: timezone
) -> None:
    # spec: offset-does-not-change-the-instant
    in_utc, in_offset = parse_batch(
        [
            metric_item(timestamp=instant.isoformat()),
            metric_item(timestamp=instant.astimezone(offset).isoformat()),
        ],
        RECEIVED_AT,
    )
    assert in_offset.timestamp == in_utc.timestamp
