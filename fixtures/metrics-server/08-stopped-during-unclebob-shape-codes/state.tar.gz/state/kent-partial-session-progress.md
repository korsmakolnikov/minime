# kent — partial session progress

- Repository: /tmp/metrics-server/project
- Branch: metrics-server (base: master)
- User's language: Italian
- Greenfield project in folder metrics-server/ (Python 3.12, FastAPI, psycopg 3, testcontainers)

## Paths
- Shopping list: .sources/shopping_lists/metrics-server.md
- Spec: .sources/spec.yaml
- ADL: .sources/system.adl
- Components map: .sources/components.yaml
- Documentation: .documentation/metrics-server/ (architecture.md, workspace.dsl)

## Step
Step 4, internals with unclebob. Workflow files committed in 429c3ad (docs(workflow)).

## Components, agreed order and scopes (confirmed by the user)
1. metrics_server.metrics — scope `metrics-server metrics` — IN PROGRESS (unclebob relaunched after the previous session died; last commit 7576269 red test "reject a metric name with a trailing dot", green change was uncommitted)
2. metrics_server.storage — scope `metrics-server storage`
3. metrics_server.api — scope `metrics-server api`
4. integration flow — scope `metrics-server`

## Decision that must be applied (user)
After the metrics unit is CLOSED and BEFORE launching unclebob on storage: have ford (mode: correction) evaluate the three architecture points raised by simon:
1. the store that is not opened at startup;
2. the fitness function on the root package;
3. Starlette and psycopg with no component.

## Units squashed
None yet.

## Unit under review
None yet (metrics will go to martin, iteration 1, after UNCLEBOB_DONE).

## Harness (python)
- tests/test_metrics.py: metric_item(**fields) and violations_of(items) helpers, RECEIVED_AT fixed UTC instant, `# spec: <id>` comment per test.
- tests/support/strategies.py: Hypothesis strategies metric_names(), utc_instants(since, until), utc_offsets(lowest, highest).
- tests/architecture/: adl_fitness.py + test_system.py (fitness functions).
- No Postgres harness yet (storage needs testcontainers + compose Postgres).

## Agent instructions for marvin
Project has no AGENTS.md/CLAUDE.md yet.
