# metrics-server

An HTTP server that receives metrics, one or a batch per request, and stores
them in Postgres.

## Development

Requires Python 3.12+ and [uv](https://docs.astral.sh/uv/) (`make deps` installs them on Arch Linux and Ubuntu).

```sh
make install    # create the environment and install the dependencies
make test       # pytest (with Hypothesis for property-based tests)
make check      # ruff format --check, ruff check, mypy --strict
make format     # format the code
```

The tests that need Postgres start their own container with testcontainers,
so they need a running Docker daemon, locally and in CI.

## Running

```sh
make up         # build the image, start Postgres and the server on port 8000
make logs       # follow the logs
make down       # stop everything (the data stays in the postgres-data volume)
```

The server reads one setting from the environment: `DATABASE_URL`, a libpq
connection URI (`postgresql://user:password@host:5432/dbname`).
