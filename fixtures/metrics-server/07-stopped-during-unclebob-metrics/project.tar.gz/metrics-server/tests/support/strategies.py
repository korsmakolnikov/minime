from datetime import UTC, datetime, timedelta, timezone
from string import ascii_lowercase, digits

from hypothesis import strategies as st

_SEGMENT_TAIL = ascii_lowercase + digits + "_"


def metric_names() -> st.SearchStrategy[str]:
    segment = st.builds(
        str.__add__,
        st.sampled_from(ascii_lowercase),
        st.text(alphabet=_SEGMENT_TAIL, max_size=40),
    )
    return st.lists(segment, min_size=2, max_size=6).map(".".join)


def utc_instants(since: datetime, until: datetime) -> st.SearchStrategy[datetime]:
    return st.datetimes(
        min_value=since.replace(tzinfo=None),
        max_value=until.replace(tzinfo=None),
        timezones=st.just(UTC),
    )


def utc_offsets(lowest: timedelta, highest: timedelta) -> st.SearchStrategy[timezone]:
    minutes = st.integers(lowest // timedelta(minutes=1), highest // timedelta(minutes=1))
    return minutes.map(lambda count: timezone(timedelta(minutes=count)))
