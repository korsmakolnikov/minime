"""Fitness functions of the metrics server architecture (``.sources/system.adl``).

ADL:METRICS SERVER

DESCRIPTION An HTTP server that receives one metric or a batch of metrics per request,
  validates them against the domain rules and stores them in Postgres, with a health check.
  metrics holds the domain and depends on nothing; storage writes validated metrics to
  Postgres behind an interface; api is the FastAPI entry point that wires the other two.
  Only storage talks to the database and only api speaks HTTP.
REQUIRES adl_fitness pytest helper (tests/architecture/adl_fitness.py)
DEFINE SYSTEM Metrics Server AS metrics_server
  DEFINE COMPONENT Metrics AS metrics
  DEFINE COMPONENT Storage AS storage
  DEFINE COMPONENT HTTP API AS api
DEFINE LIBRARY FastAPI AS fastapi
DEFINE LIBRARY Starlette AS starlette
DEFINE LIBRARY Uvicorn AS uvicorn
DEFINE LIBRARY psycopg AS psycopg
DEFINE LIBRARY psycopg pool AS psycopg_pool
ASSERT(CLASSES are only CONTAINED within COMPONENTS)
ASSERT(metrics has NO DEPENDENCY on {storage, api})
ASSERT(storage has NO DEPENDENCY on api)
ASSERT(metrics has NO DEPENDENCY on {fastapi, starlette, uvicorn, psycopg, psycopg_pool})
ASSERT(storage has NO DEPENDENCY on {fastapi, starlette, uvicorn})
ASSERT(api has NO DEPENDENCY on {psycopg, psycopg_pool})
"""

from pathlib import Path

from adl_fitness import assert_defined, assert_no_dependency, assert_only_within

SOURCE_ROOT = Path(__file__).resolve().parents[2] / "src"
SYSTEM = "metrics_server"
METRICS = "metrics_server.metrics"
STORAGE = "metrics_server.storage"
API = "metrics_server.api"
COMPONENTS = [METRICS, STORAGE, API]
WEB_LIBRARIES = ["fastapi", "starlette", "uvicorn"]
DATABASE_LIBRARIES = ["psycopg", "psycopg_pool"]


def test_every_component_is_defined() -> None:
    assert_defined(SOURCE_ROOT, SYSTEM, COMPONENTS)


def test_classes_are_only_contained_within_components() -> None:
    assert_only_within(SOURCE_ROOT, SYSTEM, COMPONENTS, allow=[SYSTEM])


def test_metrics_has_no_dependency_on_storage_or_api() -> None:
    assert_defined(SOURCE_ROOT, SYSTEM, METRICS)
    assert_no_dependency(SOURCE_ROOT, SYSTEM, METRICS, [STORAGE, API])


def test_storage_has_no_dependency_on_api() -> None:
    assert_defined(SOURCE_ROOT, SYSTEM, STORAGE)
    assert_no_dependency(SOURCE_ROOT, SYSTEM, STORAGE, API)


def test_metrics_has_no_dependency_on_web_or_database_libraries() -> None:
    assert_defined(SOURCE_ROOT, SYSTEM, METRICS)
    assert_no_dependency(SOURCE_ROOT, SYSTEM, METRICS, WEB_LIBRARIES + DATABASE_LIBRARIES)


def test_storage_has_no_dependency_on_web_libraries() -> None:
    assert_defined(SOURCE_ROOT, SYSTEM, STORAGE)
    assert_no_dependency(SOURCE_ROOT, SYSTEM, STORAGE, WEB_LIBRARIES)


def test_api_has_no_dependency_on_database_libraries() -> None:
    assert_defined(SOURCE_ROOT, SYSTEM, API)
    assert_no_dependency(SOURCE_ROOT, SYSTEM, API, DATABASE_LIBRARIES)
