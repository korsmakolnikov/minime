import math
from datetime import UTC, datetime, timedelta, timezone

import pytest
from hypothesis import given
from hypothesis import strategies as st

from metrics_server.metrics import (
    BatchTooLarge,
    EmptyBatch,
    InvalidMetrics,
    MetricType,
    Violation,
    parse_batch,
)
from support.strategies import metric_names, utc_instants, utc_offsets

RECEIVED_AT = datetime(2026, 10, 24, 12, 0, 0, tzinfo=UTC)


def metric_item(**fields: object) -> dict[str, object]:
    return {"name": "cpu.load", "type": "gauge", "value": 1.0, **fields}


def violations_of(items: list[object]) -> tuple[Violation, ...]:
    with pytest.raises(InvalidMetrics) as error:
        parse_batch(items, RECEIVED_AT)
    return error.value.violations


def test_an_empty_batch_is_rejected() -> None:
    # spec: batch-is-not-empty
    with pytest.raises(EmptyBatch):
        parse_batch([], RECEIVED_AT)


def test_a_batch_of_1001_metrics_is_too_large() -> None:
    # spec: batch-at-most-1000
    with pytest.raises(BatchTooLarge):
        parse_batch([metric_item()] * 1001, RECEIVED_AT)


def test_a_too_large_batch_of_invalid_items_reports_only_its_size() -> None:
    # spec: batch-size-error-takes-precedence
    with pytest.raises(BatchTooLarge):
        parse_batch([42] * 1001, RECEIVED_AT)


def test_a_batch_of_1000_metrics_is_accepted() -> None:
    # spec: batch-at-most-1000
    assert len(parse_batch([metric_item()] * 1000, RECEIVED_AT)) == 1000


def test_a_gauge_keeps_a_negative_value() -> None:
    # spec: gauge-value-is-any-finite-number
    (metric,) = parse_batch([metric_item(value=-3.5)], RECEIVED_AT)
    assert metric.value == -3.5


def test_a_histogram_is_one_observation_of_any_finite_value() -> None:
    # spec: histogram-value-is-one-observation
    (metric,) = parse_batch([metric_item(type="histogram", value=-2.5)], RECEIVED_AT)
    assert (metric.type, metric.value) == (MetricType.HISTOGRAM, -2.5)


def test_a_counter_with_a_negative_value_is_invalid() -> None:
    # spec: counter-value-is-not-negative
    assert violations_of([metric_item(type="counter", value=-1.0)]) == (
        Violation(0, "value", "counter-value-is-not-negative"),
    )


def test_a_nan_value_is_invalid() -> None:
    # spec: metric-value-is-finite
    assert violations_of([metric_item(value=math.nan)]) == (
        Violation(0, "value", "metric-value-is-finite"),
    )


def test_an_infinite_value_is_invalid() -> None:
    # spec: metric-value-is-finite
    assert violations_of([metric_item(value=math.inf)]) == (
        Violation(0, "value", "metric-value-is-finite"),
    )


@given(value=st.floats(max_value=0.0, exclude_max=True, allow_nan=False, allow_infinity=False))
def test_a_negative_value_is_invalid_only_for_a_counter(value: float) -> None:
    # spec: counter-rejects-negative-values
    assert violations_of([metric_item(type="counter", value=value)]) == (
        Violation(0, "value", "counter-value-is-not-negative"),
    )
    parse_batch(
        [metric_item(type="gauge", value=value), metric_item(type="histogram", value=value)],
        RECEIVED_AT,
    )


def test_a_violation_names_the_position_of_the_invalid_metric() -> None:
    # spec: ingest-invalid-metric
    assert violations_of([metric_item(), metric_item(type="counter", value=-1.0)]) == (
        Violation(1, "value", "counter-value-is-not-negative"),
    )


def test_every_invalid_metric_of_a_batch_is_reported() -> None:
    # spec: ingest-invalid-metric
    negative_counter = metric_item(type="counter", value=-1.0)
    assert violations_of([negative_counter, metric_item(), negative_counter]) == (
        Violation(0, "value", "counter-value-is-not-negative"),
        Violation(2, "value", "counter-value-is-not-negative"),
    )


@given(name=metric_names())
def test_every_valid_name_is_accepted(name: str) -> None:
    # spec: valid-names-are-accepted
    (metric,) = parse_batch([metric_item(name=name)], RECEIVED_AT)
    assert metric.name == name


def test_a_name_of_one_segment_is_invalid() -> None:
    # spec: metric-name-has-dotted-segments
    assert violations_of([metric_item(name="cpu")]) == (
        Violation(0, "name", "metric-name-has-dotted-segments"),
    )


def test_a_name_with_a_double_dot_is_invalid() -> None:
    # spec: metric-name-has-dotted-segments
    assert violations_of([metric_item(name="cpu..load")]) == (
        Violation(0, "name", "metric-name-has-dotted-segments"),
    )


def test_a_name_with_a_leading_dot_is_invalid() -> None:
    # spec: metric-name-has-dotted-segments
    assert violations_of([metric_item(name=".cpu.load")]) == (
        Violation(0, "name", "metric-name-has-dotted-segments"),
    )


def test_a_name_with_a_trailing_dot_is_invalid() -> None:
    # spec: metric-name-has-dotted-segments
    assert violations_of([metric_item(name="cpu.load.")]) == (
        Violation(0, "name", "metric-name-has-dotted-segments"),
    )


def test_a_metric_keeps_its_tags() -> None:
    (metric,) = parse_batch([metric_item(tags={"host": "web-1"})], RECEIVED_AT)
    assert metric.tags == {"host": "web-1"}


def test_a_metric_sent_without_tags_has_an_empty_tag_map() -> None:
    # spec: missing-tags-default-to-empty
    (metric,) = parse_batch([metric_item()], RECEIVED_AT)
    assert metric.tags == {}


def test_a_metric_may_carry_an_empty_tag_map() -> None:
    # spec: tags-may-be-empty
    (metric,) = parse_batch([metric_item(tags={})], RECEIVED_AT)
    assert metric.tags == {}


def test_a_metric_keeps_its_timestamp() -> None:
    (metric,) = parse_batch([metric_item(timestamp="2026-10-24T11:30:00Z")], RECEIVED_AT)
    assert metric.timestamp == datetime(2026, 10, 24, 11, 30, tzinfo=UTC)


def test_a_metric_without_a_timestamp_takes_the_instant_of_receipt() -> None:
    # spec: missing-timestamp-defaults-to-receipt
    (metric,) = parse_batch([metric_item()], RECEIVED_AT)
    assert metric.timestamp == RECEIVED_AT


def test_every_unstamped_metric_of_a_batch_shares_the_instant_of_receipt() -> None:
    # spec: batch-shares-one-receipt-instant
    metrics = parse_batch([metric_item(), metric_item(type="counter")], RECEIVED_AT)
    assert [metric.timestamp for metric in metrics] == [RECEIVED_AT, RECEIVED_AT]


def test_a_timestamp_with_an_offset_is_stored_in_utc() -> None:
    # spec: timestamp-is-stored-in-utc
    (metric,) = parse_batch([metric_item(timestamp="2026-10-24T13:30:00+02:00")], RECEIVED_AT)
    assert (metric.timestamp, metric.timestamp.tzinfo) == (
        datetime(2026, 10, 24, 11, 30, tzinfo=UTC),
        UTC,
    )


@given(
    instant=utc_instants(since=datetime(2000, 1, 1, tzinfo=UTC), until=RECEIVED_AT),
    offset=utc_offsets(lowest=timedelta(hours=-12), highest=timedelta(hours=14)),
)
def test_the_offset_of_a_timestamp_does_not_change_its_instant(
    instant: datetime, offset: timezone
) -> None:
    # spec: offset-does-not-change-the-instant
    in_utc, in_offset = parse_batch(
        [
            metric_item(timestamp=instant.isoformat()),
            metric_item(timestamp=instant.astimezone(offset).isoformat()),
        ],
        RECEIVED_AT,
    )
    assert in_offset.timestamp == in_utc.timestamp
