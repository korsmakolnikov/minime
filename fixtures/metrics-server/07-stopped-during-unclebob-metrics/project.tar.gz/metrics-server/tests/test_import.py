import metrics_server


def test_the_package_imports() -> None:
    assert metrics_server.__name__ == "metrics_server"
