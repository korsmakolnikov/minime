"""Metrics: the domain of the metrics server.

The metric, its name, its tags and the batch a request carries, and the
rules that decide whether a batch may be stored. Pure: no I/O, no web or
database library.

Boundary: concrete. Callers use this module for real; its tests need no
double, since it has no collaborator and takes the instant of receipt as
an argument.

The public interface is ``parse_batch``: it turns the decoded JSON of a
request into validated ``Metric`` values, or raises a subclass of
``InvalidBatch`` that says why nothing may be stored.
"""

import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import StrEnum

__all__ = [
    "BatchTooLarge",
    "EmptyBatch",
    "InvalidBatch",
    "InvalidMetrics",
    "Metric",
    "MetricType",
    "Violation",
    "parse_batch",
]

_MAX_BATCH_SIZE = 1000


class MetricType(StrEnum):
    """The kind of measurement a metric is."""

    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"


@dataclass(frozen=True)
class Metric:
    """One validated sample, ready to be stored.

    Only ``parse_batch`` builds it, so every field already satisfies the
    invariants of Metric, MetricName and Tags.

    Attributes:
        name: the metric name in the ``domain.subject_unit`` style.
        type: counter, gauge or histogram.
        value: a finite number; zero or greater for a counter.
        tags: string keys to string values; possibly empty, and empty when
            the client sent none.
        timestamp: an aware datetime in UTC; the instant of receipt when the
            client sent none.
    """

    name: str
    type: MetricType
    value: float
    tags: Mapping[str, str]
    timestamp: datetime


@dataclass(frozen=True)
class Violation:
    """One rule an invalid metric of a batch breaks.

    Attributes:
        index: the zero-based position of the metric in the batch.
        field: the field the rule is about (``name``, ``type``, ``value``,
            ``tags``, ``timestamp``, or the unknown field's own name); None
            when the item is not a JSON object at all.
        rule: the id of the spec invariant the metric breaks (for example
            ``metric-name-length``, ``counter-value-is-not-negative``,
            ``timestamp-carries-a-time-zone``), or one of the shape codes:
            ``not-an-object`` (the item is not a JSON object),
            ``field-missing`` (a required field is absent),
            ``field-unknown`` (a field the metric does not have),
            ``field-invalid`` (a value of the wrong JSON type, a type other
            than counter, gauge or histogram, a timestamp that is not an
            ISO 8601 string).
    """

    index: int
    field: str | None
    rule: str


class InvalidBatch(Exception):
    """The batch cannot be stored; nothing of it may be written."""


class EmptyBatch(InvalidBatch):
    """The batch holds no metrics (spec: ingest-empty-batch)."""


class BatchTooLarge(InvalidBatch):
    """The batch holds more than 1000 metrics (spec: ingest-batch-too-large)."""


class InvalidMetrics(InvalidBatch):
    """At least one metric breaks a rule (spec: ingest-invalid-metric).

    ``violations`` lists every invalid metric of the batch, ordered by index,
    with at least one entry per invalid metric and one entry per broken rule.
    """

    violations: tuple[Violation, ...]

    def __init__(self, violations: Sequence[Violation]) -> None:
        super().__init__(violations)
        self.violations = tuple(violations)


def parse_batch(items: Sequence[object], received_at: datetime) -> tuple[Metric, ...]:
    """Validate the items of a request and return them as metrics, in order.

    Args:
        items: the decoded JSON items of the batch, one per metric; a request
            carrying a single metric passes a sequence of one. Each item is
            expected to be an object with ``name``, ``type`` and ``value``,
            and optionally ``tags`` (an object of strings; an empty map when
            absent) and ``timestamp`` (an ISO 8601 string with a time zone or
            offset).
        received_at: the aware UTC instant at which the request arrived; it
            becomes the timestamp of every metric sent without one, and is
            the reference for the five-minute future limit.

    Returns:
        One metric per item, in the order of ``items``, timestamps in UTC.

    Raises:
        EmptyBatch: ``items`` is empty.
        BatchTooLarge: ``items`` holds more than 1000 items, whether or not
            any of them is invalid: the size error takes precedence and no
            item is inspected.
        InvalidMetrics: the size is valid and at least one item is not a
            valid metric.
    """
    if len(items) > _MAX_BATCH_SIZE:
        raise BatchTooLarge()
    if not items:
        raise EmptyBatch()
    violations = [
        violation for index, item in enumerate(items) for violation in _violations(index, item)
    ]
    if violations:
        raise InvalidMetrics(violations)
    return tuple(_to_metric(item, received_at) for item in items)


def _violations(index, item):
    name = item["name"]
    if "." not in name or ".." in name or name.startswith(".") or name.endswith("."):
        yield Violation(index, "name", "metric-name-has-dotted-segments")
    if not math.isfinite(item["value"]):
        yield Violation(index, "value", "metric-value-is-finite")
    if item["type"] == MetricType.COUNTER and item["value"] < 0:
        yield Violation(index, "value", "counter-value-is-not-negative")


def _to_metric(item, received_at):
    return Metric(
        name=item["name"],
        type=MetricType(item["type"]),
        value=item["value"],
        tags=item.get("tags", {}),
        timestamp=(
            datetime.fromisoformat(item["timestamp"]).astimezone(UTC)
            if "timestamp" in item
            else received_at
        ),
    )
