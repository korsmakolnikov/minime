"""HTTP API: the FastAPI entry point of the metrics server.

Receives metrics and health requests over HTTP, hands the metrics to the
domain for validation and to the store for writing, and maps every outcome
to an HTTP response. The only component that speaks HTTP.

Boundary: concrete. Nothing calls it in-process but uvicorn; its tests go
through FastAPI's ``TestClient`` with a ``MetricStore`` double, or with the
real store on a test Postgres.

HTTP contract (JSON bodies):

``POST /metrics`` (spec: ingest-metrics). The body is one metric object, or
an array of metric objects; a single object is a batch of one. A metric
object: ``name`` (string), ``type`` (``counter``, ``gauge`` or
``histogram``), ``value`` (number), optional ``tags`` (object of strings,
may be empty, an empty map when absent), optional ``timestamp`` (ISO 8601
string with a time zone or offset).

The batch is validated in full before the store is called, so the outcomes
below are exclusive and checked in this order: a size error alone, then the
violations, then the storage error, which only a valid batch can get.

* ``200`` ``{"stored": <n>}``: every metric was stored.
* ``400`` ``{"error": "malformed-body"}``: the body is not JSON, or is
  neither an object nor an array.
* ``422`` ``{"error": "empty-batch"}``: the array is empty
  (ingest-empty-batch).
* ``422`` ``{"error": "batch-too-large"}``: more than 1000 metrics
  (ingest-batch-too-large).
* ``422`` ``{"error": "invalid-metrics", "violations": [{"index": <i>,
  "field": <field or null>, "rule": <rule>}]}``: nothing was stored; one
  entry per broken rule of each invalid metric (ingest-invalid-metric).
* ``503`` ``{"error": "storage-unavailable"}``: the batch is valid in full,
  nothing was stored and the client may send the same request again
  (ingest-storage-unavailable).

``GET /health`` (spec: report-health): ``200`` ``{"status": "ready"}`` when
the store can write metrics, ``503`` ``{"status": "not-ready"}`` otherwise
(health-not-ready). Compose and the deployment wait on it.

The instant of receipt is taken once per request, in UTC, when the request
arrives.
"""

from fastapi import FastAPI

from metrics_server.storage import MetricStore

__all__ = ["create_app", "create_app_from_environment"]


def create_app(store: MetricStore) -> FastAPI:
    """Build the application on ``store``.

    The application opens the store at startup and closes it at shutdown.
    """
    raise NotImplementedError


def create_app_from_environment() -> FastAPI:
    """Build the application on Postgres, as uvicorn starts it (``--factory``).

    Reads ``DATABASE_URL``, a libpq connection URI, from the environment and
    builds the application on a ``PostgresMetricStore``.

    Raises:
        KeyError: ``DATABASE_URL`` is not set.
    """
    raise NotImplementedError
