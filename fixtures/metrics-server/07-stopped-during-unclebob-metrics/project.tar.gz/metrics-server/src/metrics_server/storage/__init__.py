"""Storage: writes validated metrics to Postgres.

The only component that talks to the database. Callers depend on the
``MetricStore`` interface, never on the Postgres implementation.

Boundary: interface. Postgres is an external system, and the callers'
tests need a seam to make the store unavailable or not ready. A test of a
caller may replace ``MetricStore`` with a double; a contract test runs the
same suite against the double and against ``PostgresMetricStore`` on a real
Postgres (testcontainers).

The table, created by ``PostgresMetricStore.open`` when it is missing, is
described by ``schema.sql`` next to this module: one row per stored sample,
no deduplication, the timestamp as ``timestamptz`` in UTC, the tags as
``jsonb``.
"""

from collections.abc import Sequence
from typing import Protocol

from metrics_server.metrics import Metric

__all__ = ["MetricStore", "PostgresMetricStore", "StorageUnavailable"]


class StorageUnavailable(Exception):
    """The storage cannot accept the metrics; nothing was written.

    The client may send the same metrics again (spec: ingest-storage-unavailable).
    """


class MetricStore(Protocol):
    """Where validated metrics are written."""

    def open(self) -> None:
        """Prepare the store before the first request.

        Raises:
            StorageUnavailable: the storage cannot be reached or prepared.
        """
        ...

    def close(self) -> None:
        """Release the store's resources after the last request."""
        ...

    def store(self, metrics: Sequence[Metric]) -> int:
        """Write every metric, or none of them, and return how many were written.

        Each metric is written as a new sample, even when an identical one is
        already stored.

        Raises:
            StorageUnavailable: nothing was written.
        """
        ...

    def is_ready(self) -> bool:
        """Whether the store can write metrics now (spec: report-health)."""
        ...


class PostgresMetricStore:
    """A ``MetricStore`` on Postgres, through a psycopg connection pool."""

    def __init__(self, database_url: str) -> None:
        """Configure the store; no connection is made until ``open``.

        Args:
            database_url: a libpq connection URI, as ``DATABASE_URL`` gives it.
        """
        raise NotImplementedError

    def open(self) -> None:
        """Open the connection pool and create the table if it is missing.

        Raises:
            StorageUnavailable: Postgres cannot be reached or the table
                cannot be created.
        """
        raise NotImplementedError

    def close(self) -> None:
        """Close the connection pool."""
        raise NotImplementedError

    def store(self, metrics: Sequence[Metric]) -> int:
        """Insert every metric in one transaction and return how many were inserted.

        Raises:
            StorageUnavailable: the transaction did not commit; nothing was
                inserted.
        """
        raise NotImplementedError

    def is_ready(self) -> bool:
        """Whether Postgres answers a query through the pool."""
        raise NotImplementedError
