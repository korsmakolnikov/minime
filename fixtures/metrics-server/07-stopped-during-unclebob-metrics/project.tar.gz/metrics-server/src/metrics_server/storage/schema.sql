-- The table of stored metrics: one row per received sample, duplicates
-- included. PostgresMetricStore.open runs this file; it is idempotent.
CREATE TABLE IF NOT EXISTS metrics (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name        text             NOT NULL,
    type        text             NOT NULL,
    value       double precision NOT NULL,
    tags        jsonb            NOT NULL,
    recorded_at timestamptz      NOT NULL
);
