# Shopping list — metrics-server

## Goal

A new Python project, `metrics-server/`, in the observability-lab repository: an HTTP server that receives metrics and stores them in Postgres (roadmap item 1). Greenfield, in the folder `metrics-server/` of the existing repository.

## Language and constraints (set by the user)

- Python 3.12, FastAPI, psycopg 3 with hand-written SQL (no ORM).
- testcontainers for the tests that run against Postgres.
- A Dockerfile, a docker-compose with Postgres, CI.
- Lab conventions (`docs/conventions.md`): a self-contained folder with its own Makefile, tests and CI; services run locally with docker compose; timestamps are always UTC; metric names follow the `domain.subject_unit` style (e.g. `http.request_duration_seconds`).

## Scope

In scope:
- Receiving one metric, or a batch of metrics, per request.
- Writing them to Postgres.
- A health-check endpoint (compose and the deployment wait on it).

Out of scope:
- Reading or querying metrics.
- Authentication.
- Alerting.
- Retention.

## Domain decisions already taken (user)

- A metric has a name, a type (`counter`, `gauge`, `histogram`), a value, tags and a timestamp.
- Tags are a map of string keys to string values, stored as `jsonb`.
- When the timestamp is missing, it defaults to the time of receipt.

## Settled questions (domain, answered with hughes; see `.sources/spec.yaml`)

The user chose the name rule and delegated every other domain choice to hughes's recommendations.
- Name (user): lowercase ASCII letters, digits and underscores; at least two dot-separated segments, each non-empty and starting with a letter; at most 255 characters.
- Values: always a finite number (no NaN or infinity); a counter is >= 0; a gauge is any finite number; a histogram value is a single observation, any finite number.
- A batch is all-or-nothing: one invalid metric stores nothing, and the client gets the position and the violated rule of every invalid metric. A batch holds 1 to 1000 metrics; a single metric is a batch of one.
- Duplicates are stored: no deduplication.
- A timestamp up to 5 minutes after receipt is accepted, a later one is rejected; a timestamp without a time zone is rejected; one with an offset is converted to UTC. Every metric of a batch without a timestamp gets the same receipt instant.
- Tags: at most 32; keys of 1 to 100 characters, values of 1 to 255; an empty map is allowed.
- No domain events.

## Open questions

Owner ford (technology):
- The endpoints and their HTTP status codes.
- The table schema, and how the schema is created (migrations).
- The connection pool.
- Whether the health check also checks the database.
- Configuration through environment variables.
- How the CI runs testcontainers.

## Agent instructions

The project has no `AGENTS.md` or `CLAUDE.md` yet; marvin writes them at the end.
