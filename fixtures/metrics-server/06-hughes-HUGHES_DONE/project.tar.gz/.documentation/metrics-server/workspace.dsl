// C4 model of the metrics-server branch.
// No ADL exists yet in .sources/: the model is empty until ford's report.
workspace "metrics-server" "HTTP server that receives metrics and stores them in Postgres (source: .sources/shopping_lists/metrics-server.md)." {

    model {
    }

    views {
    }

}
